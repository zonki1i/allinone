<?php
require_once 'config.php';

try {
    $stmt = $conn->prepare("DELETE FROM reviews");
    $stmt->execute();
    echo "All reviews have been deleted successfully.";
} catch (PDOException $e) {
    echo "Error deleting reviews: " . $e->getMessage();
}
?>
