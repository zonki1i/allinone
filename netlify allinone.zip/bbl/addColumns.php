<?php
require 'config.php';


$sql = "ALTER TABLE users ADD COLUMN example_column VARCHAR(50)";


if ($conn->query($sql) === TRUE) {
echo "Column added successfully";
} else {
echo "Error adding column: " . $conn->error;
}
?>