<?php
session_start();
require 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$review_id = $_GET['id'] ?? null;
$message = '';
$error = '';

// Fetch the review
if ($review_id) {
    $stmt = $conn->prepare("SELECT * FROM reviews WHERE id = ? AND user_id = ?");
    $stmt->execute([$review_id, $user_id]);
    $review = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$review) {
        $error = "Review not found or you don't have permission to edit it.";
    }
} else {
    $error = "No review ID provided.";
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error) {
    $rating = $_POST['rating'] ?? null;
    $review_text = $_POST['review'] ?? '';
    
    if ($rating && $review_text) {
        $stmt = $conn->prepare("UPDATE reviews SET rating = ?, review = ? WHERE id = ? AND user_id = ?");
        if ($stmt->execute([$rating, $review_text, $review_id, $user_id])) {
            $message = "Review updated successfully!";
            // Refresh the review data
            $stmt = $conn->prepare("SELECT * FROM reviews WHERE id = ? AND user_id = ?");
            $stmt->execute([$review_id, $user_id]);
            $review = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $error = "Failed to update review.";
        }
    } else {
        $error = "Please fill in all fields.";
    }
}

// Handle delete
if (isset($_GET['action']) && $_GET['action'] === 'delete' && $review_id) {
    $stmt = $conn->prepare("DELETE FROM reviews WHERE id = ? AND user_id = ?");
    if ($stmt->execute([$review_id, $user_id])) {
        header("Location: reviewslog.php?deleted=1");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Review - ALLINONE</title>
    <!-- Google Font: Oswald (Variable) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Oswald", sans-serif;
            font-optical-sizing: auto;
            font-style: normal;
            background-color: #f5f7fb;
            color: #212529;
        }

        .container {
            width: 100%;
            max-width: 800px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .form-container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-bottom: 30px;
            color: #3a86ff;
            font-size: 2rem;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 700;
            color: #212529;
        }

        input[type="number"],
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            font-family: "Oswald", sans-serif;
        }

        textarea {
            min-height: 150px;
            resize: vertical;
        }

        input[type="number"]:focus,
        textarea:focus {
            outline: none;
            border-color: #3a86ff;
            box-shadow: 0 0 5px rgba(58, 134, 255, 0.3);
        }

        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 30px;
        }

        button, .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            font-weight: 700;
            cursor: pointer;
            font-family: "Oswald", sans-serif;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3a86ff 0%, #1b63e8 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(58, 134, 255, 0.4);
        }

        .btn-danger {
            background-color: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        .message {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #3a86ff;
            text-decoration: none;
            font-weight: 600;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="reviewslog.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Reviews</a>
        
        <div class="form-container">
            <h1>Edit Your Review</h1>

            <?php if ($message): ?>
                <div class="message success"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="message error"><?php echo htmlspecialchars($error); ?></div>
            <?php else: ?>
                <form method="POST">
                    <div class="form-group">
                        <label for="rating">Rating (1-5 stars):</label>
                        <input type="number" id="rating" name="rating" min="1" max="5" value="<?php echo $review['rating']; ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="review">Review:</label>
                        <textarea id="review" name="review" required><?php echo htmlspecialchars($review['review']); ?></textarea>
                    </div>

                    <div class="button-group">
                        <button type="submit" class="btn btn-primary">Update Review</button>
                        <a href="reviewslog.php?action=delete&id=<?php echo $review_id; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this review?');">Delete Review</a>
                        <a href="reviewslog.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
