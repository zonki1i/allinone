<?php
require 'config.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';

    if (!empty($email) && !empty($username) && !empty($password) && !empty($role)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        try {
            $stmt = $conn->prepare(
                "INSERT INTO users (email, username, password, role)
                 VALUES (:email, :username, :password, :role)"
            );

            $stmt->execute([
                ':email'    => $email,
                ':username' => $username,
                ':password' => $hashed_password,
                ':role'     => $role
            ]);

            header("Location: login.php?signup=success");
            exit;

        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate entry') !== false || strpos($e->getMessage(), 'UNIQUE') !== false) {
                $error = "Email or username already exists.";
            } else {
                $error = "Error: " . $e->getMessage();
            }
        }
    } else {
        $error = "Please fill in all fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - ALLINONE</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: "Oswald", sans-serif;
            background: linear-gradient(135deg, #3a86ff 0%, #8338ec 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        .logo {
            position: absolute;
            top: 30px;
            left: 30px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: 700;
            color: white;
            text-decoration: none;
        }

        .logo i {
            font-size: 2rem;
        }

        .logo span {
            font-style: italic;
        }

        .card {
            width: 100%;
            max-width: 400px;
            padding: 40px 35px;
            border-radius: 15px;
            background-color: #fff;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }

        h2 {
            text-align: center;
            color: #3a86ff;
            margin-bottom: 10px;
            font-size: 1.8rem;
        }

        .subtitle {
            text-align: center;
            color: #6c757d;
            margin-bottom: 30px;
            font-size: 0.95rem;
        }

        input {
            width: 100%;
            padding: 14px;
            margin-bottom: 16px;
            border-radius: 8px;
            border: 1px solid #ddd;
            font-size: 15px;
            transition: border-color 0.3s;
        }

        input:focus {
            outline: none;
            border-color: #3a86ff;
        }

        button {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #3a86ff, #8338ec);
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s;
        }

        button:hover {
            transform: translateY(-2px);
        }

        .login-link {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
            color: #6c757d;
        }

        .login-link a {
            color: #3a86ff;
            text-decoration: none;
            font-weight: 600;
        }        .login-link {
            margin-top: 18px;
            text-align: center;
            font-size: 14px;
        }

        .login-link a {
            color: #3a86ff;
            text-decoration: none;
            font-weight: bold;
        }

        .error {
            color: #e63946;
            text-align: center;
            margin-bottom: 14px;
            font-size: 14px;
        }

        .role-selector {
            margin-bottom: 20px;
        }

        .role-selector label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #3a86ff;
            font-size: 14px;
        }

        .role-options {
            display: flex;
            gap: 12px;
            justify-content: space-between;
        }

        .role-option {
            flex: 1;
            position: relative;
        }

        .role-option input[type="radio"] {
            display: none;
        }

        .role-option label {
            display: block;
            padding: 12px;
            text-align: center;
            border: 2px solid #ddd;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            color: #333;
            margin-bottom: 0;
            transition: all 0.3s;
        }

        .role-option input[type="radio"]:checked + label {
            background-color: #3a86ff;
            color: white;
            border-color: #3a86ff;
        }

        .role-option label:hover {
            border-color: #3a86ff;
        }

        @media (max-width: 360px) {
            .card {
                padding: 24px 20px;
            }

            h2 {
                font-size: 1.4rem;
            }
        }
    </style>
</head>
<body>
    <div class="card">
        <h2>Create Account</h2>

        <?php
        if (!empty($error)) {
            echo "<div class='error'>$error</div>";
        }
        ?>
        
        <form method="POST" action="">
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            
            <div class="role-selector">
                <label>I am a:</label>
                <div class="role-options">
                    <div class="role-option">
                        <input type="radio" id="freelancer" name="role" value="freelancer" required>
                        <label for="freelancer">Freelancer</label>
                    </div>
                    <div class="role-option">
                        <input type="radio" id="job_seeker" name="role" value="job_seeker" required>
                        <label for="job_seeker">Job Seeker</label>
                    </div>
                    <div class="role-option">
                        <input type="radio" id="business" name="role" value="business" required>
                        <label for="business">Business</label>
                    </div>
                </div>
            </div>
            
            <button type="submit">Sign Up</button>
        </form>
        
        <div class="login-link">
            Already have an account? <a href="login.php">Log in</a>
        </div>
    </div>
</body>
</html>