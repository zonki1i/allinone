<?php
session_start();
require 'config.php';




if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$current_role = null;

try {
    $ur = $conn->prepare("SELECT role FROM users WHERE id = ?");
    $ur->execute([$_SESSION['user_id']]);
    $ud = $ur->fetch(PDO::FETCH_ASSOC);
    $current_role = $ud['role'] ?? null;
} catch (Exception $e) {
    $current_role = null;
}


if (empty($current_role)) {
    echo "You must complete your profile before viewing job listings.";
    exit();
}


if (!empty($_SESSION['role_override'])) {
    $current_role = $_SESSION['role_override'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Find Jobs - ALLINONE</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Oswald", sans-serif;
            font-optical-sizing: auto;
            font-style: normal;
        }

        :root {
            --primary-color: #3a86ff;
            --secondary-color: #8338ec;
            --accent-color: #ff006e;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --gray-color: #6c757d;
            --success-color: #38b000;
        }

        body {
            line-height: 1.6;
            color: var(--dark-color);
            background-color: #f5f7fb;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header */
        header {
            background-color: white;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--primary-color);
            text-decoration: none;
        }

        .logo span {
            color: var(--secondary-color);
        }

        .logo i {
            font-size: 1.8rem;
        }

        nav ul {
            display: flex;
            list-style: none;
            gap: 30px;
        }

        nav a {
            text-decoration: none;
            color: var(--dark-color);
            font-weight: 500;
            transition: color 0.3s;
        }

        nav a:hover {
            color: var(--primary-color);
        }

        .cta-button {
            background: linear-gradient(135deg, #3a86ff 0%, #1b63e8 100%);
            color: white;
            padding: 14px 35px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 800;
            font-size: 1rem;
            font-family: "Oswald", sans-serif;
            letter-spacing: 1px;
            transition: all 0.4s cubic-bezier(0.23, 1, 0.320, 1);
            box-shadow: 0 8px 25px rgba(58, 134, 255, 0.4);
            border: none;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
            display: inline-block;
        }

        .cta-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s ease;
            z-index: 1;
        }

        .cta-button::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.1) 0%, transparent 100%);
            pointer-events: none;
        }

        .cta-button:hover {
            transform: translateY(-3px) scale(1.08);
            box-shadow: 0 12px 35px rgba(58, 134, 255, 0.5);
            background: linear-gradient(135deg, #1b63e8 0%, #0d47a1 100%);
        }

        .cta-button:hover::before {
            left: 100%;
        }

        .cta-button:active {
            transform: translateY(-1px);
            box-shadow: 0 5px 15px rgba(58, 134, 255, 0.4);
        }

        /* Hero Section */
        .hero {
            padding: 100px 0;
            background: linear-gradient(135deg, #3a86ff 0%, #8338ec 100%);
            text-align: center;
            color: white;
        }

        .hero h1 {
            font-size: 3.5rem;
            margin-bottom: 20px;
            font-weight: 700;
        }

        .hero p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto;
            opacity: 0.95;
        }

        /* Search Section */
        .search-section {
            padding: 80px 0;
            background-color: white;
        }

        .search-section h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 50px;
            color: var(--dark-color);
            font-weight: 700;
        }

        .search-form {
            max-width: 900px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1fr 1fr 150px;
            gap: 15px;
            align-items: end;
        }

        .search-form input,
        .search-form select {
            padding: 14px 16px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 15px;
            transition: border-color 0.3s;
        }

        .search-form input:focus,
        .search-form select:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(58, 134, 255, 0.1);
        }

        .search-btn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .search-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(58, 134, 255, 0.3);
        }

        /* Jobs Section */
        .jobs-section {
            padding: 80px 0;
            background-color: #f5f7fb;
        }

        .jobs-section h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 50px;
            color: var(--dark-color);
            font-weight: 700;
        }

        .jobs-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(330px, 1fr));
            gap: 25px;
        }

        .job-card {
            background-color: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s, box-shadow 0.3s;
            display: flex;
            flex-direction: column;
        }

        .job-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
        }

        .job-title {
            font-size: 1.4rem;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--dark-color);
        }

        .job-company {
            color: var(--gray-color);
            margin-bottom: 12px;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .job-salary {
            color: var(--secondary-color);
            font-weight: 700;
            margin-bottom: 15px;
            font-size: 1.1rem;
        }

        .job-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 20px;
            margin-top: auto;
        }

        .job-tag {
            background-color: #e8f0ff;
            color: var(--primary-color);
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .apply-btn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
            width: 100%;
            font-size: 0.95rem;
        }

        .apply-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(58, 134, 255, 0.3);
        }

        .apply-btn:active {
            transform: translateY(0);
        }

        /* Footer */
        footer {
            background: linear-gradient(135deg, var(--dark-color) 0%, #1a1f26 100%);
            color: white;
            padding: 50px 0 20px;
            text-align: center;
        }

        footer p {
            opacity: 0.8;
            font-size: 0.9rem;
        }

        /* Mobile Menu Button */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--dark-color);
            cursor: pointer;
        }

        /* From Uiverse.io by adamgiebl */
        .neu-button {
            background-color: #e0e0e0;
            border-radius: 50px;
            box-shadow: inset 4px 4px 10px #bcbcbc, inset -4px -4px 10px #ffffff;
            color: #4d4d4d;
            cursor: pointer;
            font-family: "Oswald", sans-serif;
            font-size: 16px;
            font-weight: 600;
            padding: 10px 20px;
            transition: all 0.2s ease-in-out;
            border: 2px solid rgb(206, 206, 206);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .neu-button:hover {
            box-shadow: inset 2px 2px 5px #bcbcbc, inset -2px -2px 5px #ffffff, 2px 2px 5px #bcbcbc, -2px -2px 5px #ffffff;
        }

        .neu-button:focus {
            outline: none;
            box-shadow: inset 2px 2px 5px #bcbcbc, inset -2px -2px 5px #ffffff, 2px 2px 5px #bcbcbc, -2px -2px 5px #ffffff;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .search-form {
                grid-template-columns: 1fr 1fr;
            }

            .search-btn {
                grid-column: 1 / -1;
            }

            .jobs-grid {
                grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            }

            nav ul {
                gap: 20px;
            }
        }

        @media (max-width: 768px) {
            .header-content {
                padding: 12px 0;
                gap: 15px;
            }

            .logo {
                font-size: 1.4rem;
            }

            .logo i {
                font-size: 1.5rem;
            }

            nav {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: white;
                flex-direction: column;
                padding: 20px;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
                z-index: 99;
            }

            nav.active {
                display: flex;
            }

            nav ul {
                flex-direction: column;
                gap: 15px;
            }

            .mobile-menu-btn {
                display: block;
            }

            .cta-button {
                display: none;
            }

            .hero {
                padding: 60px 0;
            }

            .hero h1 {
                font-size: 2rem;
            }

            .hero p {
                font-size: 1rem;
            }

            .search-section {
                padding: 50px 0;
            }

            .search-section h2,
            .jobs-section h2 {
                font-size: 1.8rem;
                margin-bottom: 30px;
            }

            .search-form {
                grid-template-columns: 1fr;
                gap: 12px;
            }

            .search-btn {
                grid-column: auto;
            }

            .jobs-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .job-card {
                padding: 20px;
            }

            .job-title {
                font-size: 1.2rem;
            }

            .jobs-section {
                padding: 50px 0;
            }
        }

        @media (max-width: 480px) {
            .header-content {
                padding: 10px 0;
            }

            .logo {
                font-size: 1.2rem;
            }

            .logo i {
                font-size: 1.3rem;
            }

            .hero {
                padding: 40px 0;
            }

            .hero h1 {
                font-size: 1.5rem;
            }

            .hero p {
                font-size: 0.95rem;
            }

            .search-section {
                padding: 30px 0;
            }

            .search-section h2,
            .jobs-section h2 {
                font-size: 1.5rem;
                margin-bottom: 25px;
            }

            .search-form input,
            .search-form select,
            .search-btn {
                font-size: 14px;
                padding: 12px 14px;
            }

            .job-card {
                padding: 15px;
            }

            .job-title {
                font-size: 1.1rem;
            }

            .jobs-grid {
                gap: 15px;
            }

            .apply-btn {
                padding: 10px 20px;
                font-size: 0.9rem;
            }

            .job-tags {
                gap: 6px;
            }

            .job-tag {
                padding: 4px 10px;
                font-size: 0.75rem;
            }

            .jobs-section {
                padding: 30px 0;
            }

            footer {
                padding: 30px 0 15px;
            }
        }
    </style>
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <a href="<?php echo isset($_SESSION['user_id']) ? 'indexlog.php' : 'index.php'; ?>" class="logo">
                    <i class="fas fa-briefcase"></i>
                    ALL<span>IN</span>ONE
                </a>

                <nav>
                    <ul>
                        <li><a href="<?php echo isset($_SESSION['user_id']) ? 'indexlog.php' : 'index.php'; ?>">Home</a></li>
                        <li><a href="freelancing.php">Freelancers</a></li>
                        <li><a href="jobs.php">Jobs</a></li>
                        <li><a href="hire.php">Hire</a></li>
                        <li><a href="reviews.php">Reviews</a></li>
                    </ul>
                </nav>

                <?php if (!isset($_SESSION['user_id'])): ?>
                <a href="signUp.php" class="cta-button">Get Started</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Find Your Dream Job</h1>
            <p>Discover full-time and part-time opportunities that match your skills and career goals. Start your journey today.</p>
        </div>
    </section>
    </section>

    <!-- Role Cards Section -->
    <section class="role-cards-section">
        <div class="container">
            <?php
                // Determine which cards to show based on role
                $visible = ['businesses', 'freelancers', 'job_seekers'];
                if ($current_role === 'job_seeker') {
                    $visible = ['businesses', 'job_seekers'];
                } elseif ($current_role === 'freelancer') {
                    $visible = ['businesses', 'freelancers'];
                } elseif ($current_role === 'business') {
                    $visible = ['businesses', 'freelancers', 'job_seekers'];
                }

                $cards = [
                    'businesses' => [
                        'title' => 'Businesses',
                        'desc' => 'Post jobs, hire talent and manage listings.',
                        'icon' => 'fa-briefcase',
                        'link' => 'post_job.php'
                    ],
                    'freelancers' => [
                        'title' => 'Freelancers',
                        'desc' => 'Find freelance opportunities and browse profiles.',
                        'icon' => 'fa-user-tie',
                        'link' => 'jobs.php'
                    ],
                    'job_seekers' => [
                        'title' => 'Job Seekers',
                        'desc' => 'Find full-time and part-time job opportunities.',
                        'icon' => 'fa-users',
                        'link' => 'jobs.php'
                    ]
                ];
            ?>

            <div class="cards-grid">
                <?php foreach ($visible as $key): $c = $cards[$key]; ?>
                    <a href="<?php echo htmlspecialchars($c['link']); ?>" class="role-card" aria-label="<?php echo htmlspecialchars($c['title']); ?>">
                        <div class="role-icon"><i class="fas <?php echo $c['icon']; ?>"></i></div>
                        <div class="role-content">
                            <div class="role-title"><?php echo htmlspecialchars($c['title']); ?></div>
                            <div class="role-desc"><?php echo htmlspecialchars($c['desc']); ?></div>
                        </div>
                        <div class="role-cta"><i class="fas fa-arrow-right"></i></div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        <style>
            .role-cards-section { padding: 30px 0; }
            .cards-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 20px; max-width: 1100px; margin: 0 auto; }
            .role-card { background: linear-gradient(135deg, #007bff 0%, #8a2be2 100%); color: white; padding: 22px; border-radius: 12px; display: flex; gap: 18px; align-items: center; text-decoration: none; box-shadow: 0 12px 30px rgba(51, 51, 102, 0.12); transition: transform .18s, box-shadow .18s; }
            .role-card:hover { transform: translateY(-6px); box-shadow: 0 18px 46px rgba(51, 51, 102, 0.18); }
            .role-icon { background: rgba(255,255,255,0.12); color: white; padding: 14px; border-radius: 10px; font-size: 1.4rem; display: flex; align-items:center; justify-content:center; width:56px; height:56px; }
            .role-title { font-weight:800; font-size:1.05rem; color: #ffffff; }
            .role-desc { color: rgba(255,255,255,0.9); font-size:0.95rem; margin-top:4px; opacity:0.95 }
            .role-cta { margin-left: auto; color: rgba(255,255,255,0.95); font-size:1.05rem; }
            @media (max-width: 900px) { .cards-grid { grid-template-columns: repeat(2, 1fr); } }
            @media (max-width: 560px) { .cards-grid { grid-template-columns: 1fr; } .role-card { padding:16px; } }
        </style>
    </section>

    <!-- Search Section -->
    <?php if ($current_role !== 'business' || !isset($_SESSION['user_id'])): ?>
    <section class="search-section">
        <div class="container">
            <h2>Search Jobs</h2>
            <form class="search-form" action="jobs.php" method="GET">
                <input type="text" name="keyword" placeholder="Job title or keyword" value="<?php echo isset($_GET['keyword']) ? htmlspecialchars($_GET['keyword']) : ''; ?>">
                <select name="category">
                    <option value="">All Categories</option>
                    <option value="technology" <?php echo (isset($_GET['category']) && $_GET['category'] == 'technology') ? 'selected' : ''; ?>>Technology</option>
                    <option value="marketing" <?php echo (isset($_GET['category']) && $_GET['category'] == 'marketing') ? 'selected' : ''; ?>>Marketing</option>
                    <option value="design" <?php echo (isset($_GET['category']) && $_GET['category'] == 'design') ? 'selected' : ''; ?>>Design</option>
                    <option value="sales" <?php echo (isset($_GET['category']) && $_GET['category'] == 'sales') ? 'selected' : ''; ?>>Sales</option>
                    <option value="other" <?php echo (isset($_GET['category']) && $_GET['category'] == 'other') ? 'selected' : ''; ?>>Other</option>
                </select>
                <button type="submit" class="search-btn">Search</button>
            </form>
        </div>
    </section>
    <?php endif; ?>

    <!-- Jobs Section -->
    <section class="jobs-section">
        <div class="container">
            <?php
            // If the current user is a business, show their jobs; otherwise show all jobs
            if ($current_role === 'business' && isset($_SESSION['user_id'])) {
                echo '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">';
                echo '<h2 style="margin:0;">My Jobs</h2>';
                echo '<a href="post_job.php" class="cta-button" style="padding:10px 18px;">Post a Job</a>';
                echo '</div>';

                // Handle delete action
                if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
                    $jobId = intval($_POST['job_id']);
                    try {
                        $stmt = $conn->prepare("DELETE FROM jobs WHERE id = ? AND user_id = ?");
                        $stmt->execute([$jobId, $_SESSION['user_id']]);
                        echo '<div style="background: #d4edda; color: #155724; padding: 12px 15px; border-radius: 8px; margin-bottom: 20px;">Job deleted successfully!</div>';
                    } catch (Exception $e) {
                        echo '<div style="background: #f8d7da; color: #721c24; padding: 12px 15px; border-radius: 8px; margin-bottom: 20px;">Error deleting job.</div>';
                    }
                }

                // Fetch user's jobs
                try {
                    $stmt = $conn->prepare("SELECT * FROM jobs WHERE user_id = ? ORDER BY created_at DESC");
                    $stmt->execute([$_SESSION['user_id']]);
                    $userJobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                } catch (Exception $e) {
                    $userJobs = [];
                }

                if (count($userJobs) > 0) {
                    echo '<div class="jobs-grid">';
                    foreach ($userJobs as $job) {
                        $salary = '';
                        if ($job['salary_min'] && $job['salary_max']) {
                            $salary = '$' . number_format($job['salary_min'], 0) . ' - $' . number_format($job['salary_max'], 0) . ' per year';
                        } elseif ($job['salary_min']) {
                            $salary = 'From $' . number_format($job['salary_min'], 0) . ' per year';
                        }

                        $tags = $job['skills_required'] ? array_map('trim', explode(',', $job['skills_required'])) : [$job['job_type']];

                        echo '<div class="job-card">';
                        echo '<h3 class="job-title">' . htmlspecialchars($job['job_title']) . '</h3>';
                        echo '<p class="job-company">' . htmlspecialchars($job['company_name']) . '</p>';
                        echo '<p class="job-salary">' . ($salary ?: 'Competitive Salary') . '</p>';
                        echo '<p style="color: #6c757d; font-size: 0.95rem; margin-bottom: 15px;"><i class="fas fa-map-marker-alt"></i> ' . htmlspecialchars($job['location']) . '</p>';
                        echo '<div class="job-tags">';
                        foreach (array_slice($tags, 0, 3) as $tag) {
                            echo '<span class="job-tag">' . htmlspecialchars($tag) . '</span>';
                        }
                        echo '</div>';
                        echo '<div style="display: flex; gap: 10px; margin-top: 15px;">';
                        echo '<a href="edit.php?job_id=' . $job['id'] . '" class="neu-button" style="flex: 1; text-align: center; padding: 10px; text-decoration: none;"><span style="background: none !important; padding: 0 !important;">Edit</span></a>';
                        echo '<form method="POST" style="flex: 1;" onsubmit="return confirm(\'Are you sure you want to delete this job?\');">';
                        echo '<input type="hidden" name="action" value="delete">';
                        echo '<input type="hidden" name="job_id" value="' . $job['id'] . '">';
                        echo '<button type="submit" class="neu-button" style="width: 100%; padding: 10px;"><span style="background: none !important; padding: 0 !important;">Delete</span></button>';
                        echo '</form>';
                        echo '</div>';
                        echo '</div>';
                    }
                    echo '</div>';
                } else {
                    echo '<div style="text-align: center; padding: 40px 20px; background: white; border-radius: 8px;">';
                    echo '<p style="font-size: 1.1rem; color: #666; margin-bottom: 20px;">You haven\'t posted any jobs yet.</p>';
                    echo '<a href="post_job.php" class="cta-button" style="display: inline-block; padding: 12px 25px;">Post Your First Job</a>';
                    echo '</div>';
                }
            } else {
                echo '<h2>Latest Jobs</h2>';

                // Fetch jobs from database - filter for freelancers to only show freelance jobs
                try {
                    if ($current_role === 'freelancer') {
                        $stmt = $conn->prepare("SELECT * FROM jobs ORDER BY created_at DESC");
                    } else {
                        $stmt = $conn->prepare("SELECT * FROM jobs ORDER BY created_at DESC");
                    }
                    $stmt->execute();
                    $databaseJobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                } catch (Exception $e) {
                    $databaseJobs = [];
                }

                // Convert database jobs to array format
                $formattedJobs = [];
                foreach ($databaseJobs as $dbJob) {
                    $salary = '';
                    if ($dbJob['salary_min'] && $dbJob['salary_max']) {
                        $salary = '$' . number_format($dbJob['salary_min'], 0) . ' - $' . number_format($dbJob['salary_max'], 0) . ' per year';
                    } elseif ($dbJob['salary_min']) {
                        $salary = 'From $' . number_format($dbJob['salary_min'], 0) . ' per year';
                    }

                    $tags = $dbJob['skills_required'] ? array_map('trim', explode(',', $dbJob['skills_required'])) : [$dbJob['job_type']];

                    $formattedJobs[] = [
                        'id' => $dbJob['id'],
                        'title' => $dbJob['job_title'],
                        'company' => $dbJob['company_name'],
                        'salary' => $salary ?: 'Competitive Salary',
                        'tags' => array_slice($tags, 0, 3),
                        'description' => $dbJob['description'],
                        'location' => $dbJob['location'],
                        'type' => $dbJob['job_type']
                    ];
                }

                // Filter jobs based on search parameters
                $filteredJobs = $formattedJobs;

                if (isset($_GET['keyword']) && !empty($_GET['keyword'])) {
                    $keyword = strtolower($_GET['keyword']);
                    $filteredJobs = array_filter($filteredJobs, function($job) use ($keyword) {
                        return strpos(strtolower($job['title']), $keyword) !== false ||
                               strpos(strtolower($job['company']), $keyword) !== false ||
                               array_filter($job['tags'], function($tag) use ($keyword) {
                                   return strpos(strtolower($tag), $keyword) !== false;
                               });
                    });
                }

                if (count($filteredJobs) > 0) {
                    echo '<div class="jobs-grid">';
                    foreach ($filteredJobs as $job) {
                        echo '<a href="view_job.php?id=' . $job['id'] . '" style="text-decoration: none; color: inherit;">';
                        echo '<div class="job-card">';
                        echo '<h3 class="job-title">' . htmlspecialchars($job['title']) . '</h3>';
                        echo '<p class="job-company">' . htmlspecialchars($job['company']) . '</p>';
                        echo '<p class="job-salary">' . htmlspecialchars($job['salary']) . '</p>';
                        echo '<p style="color: #6c757d; font-size: 0.95rem; margin-bottom: 15px;"><i class="fas fa-map-marker-alt"></i> ' . htmlspecialchars($job['location']) . '</p>';
                        echo '<div class="job-tags">';
                        foreach ($job['tags'] as $tag) {
                            echo '<span class="job-tag">' . htmlspecialchars($tag) . '</span>';
                        }
                        echo '</div>';
                        echo '<button class="apply-btn">View Job & Apply</button>';
                        echo '</div>';
                        echo '</a>';
                    }
                    echo '</div>';
                } else {
                    echo '<div class="no-jobs">';
                    echo '<p>No jobs found matching your criteria.</p>';
                    echo '</div>';
                }
            }
            ?>
        </div>
    </section>

    <!-- Footer -->
    <footer id="legal">
        <div class="container footer-content-wrapper">
            <div class="footer-columns">
                <!-- About Us -->
                <div class="footer-column">
                    <h3>About Us</h3>
                    <ul>
                        <li><a href="#">Our Mission</a></li>
                        <li><a href="#">Team</a></li>
                        <li><a href="#">Careers</a></li>
                        <li><a href="#">Press</a></li>
                    </ul>
                </div>

                <!-- For Freelancers -->
                <div class="footer-column">
                    <h3>For Freelancers</h3>
                    <ul>
                        <li><a href="#">Find Projects</a></li>
                        <li><a href="#">Build Portfolio</a></li>
                        <li><a href="#">Freelancer Resources</a></li>
                        <li><a href="#">Community</a></li>
                    </ul>
                </div>

                <!-- For Businesses -->
                <div class="footer-column">
                    <h3>For Businesses</h3>
                    <ul>
                        <li><a href="#">Hire Talent</a></li>
                        <li><a href="#">Post Projects</a></li>
                        <li><a href="#">B2B Services</a></li>
                        <li><a href="#">Enterprise Solutions</a></li>
                    </ul>
                </div>

                <!-- Legal -->
                <div class="footer-column">
                    <h3>Legal</h3>
                    <ul>
                        <li><a href="#">Terms of Service</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Cookie Policy</a></li>
                        <li><a href="#">GDPR</a></li>
                    </ul>
                    <div class="notice">
                        <p>allinone.com is a platform connecting freelancers, job seekers, and businesses. We do not charge any commission fees.</p>
                    </div>
                </div>
            </div>

            <div class="copyright">
                &copy; 2025 allinone.com. All rights reserved.
            </div>
        </div>
    </footer>

    <style>
        /* Footer Styles */
        footer {
            position: relative;
            color: white;
            background-color: blue;
            overflow: hidden;
        }

        .footer-wave {
            position: absolute;
            top: -150px;
            left: 0;
            width: 100%;
            height: 150px;
            z-index: 1;
        }

        .footer-wave svg {
            width: 100%;
            height: 100%;
        }

        .footer-content-wrapper {
            position: relative;
            z-index: 2;
            padding: 60px 0 40px;
        }

        .footer-columns {
            display: flex;
            flex-wrap: wrap;
            gap: 50px;
            margin-bottom: 40px;
        }

        .footer-column {
            flex: 1;
            min-width: 200px;
        }

        .footer-column h3 {
            font-size: 1.3rem;
            margin-bottom: 20px;
            color: white;
        }

        .footer-column ul {
            list-style: none;
        }

        .footer-column ul li {
            margin-bottom: 10px;
        }

        .footer-column a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-column a:hover {
            color: white;
        }

        .notice {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.8);
        }

        .copyright {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.9rem;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .footer-columns {
                gap: 30px;
            }
        }

        @media (max-width: 768px) {
            .footer-columns {
                flex-direction: column;
                gap: 40px;
            }
            .footer-column {
                min-width: 100%;
            }
        }
    </style>

    <script>
        // Handle Apply Now buttons
        function applyForJob(jobId) {
            <?php if (!isset($_SESSION['user_id'])): ?>
                window.location.href = 'signUp.php';
            <?php else: ?>
                if (confirm('Are you sure you want to apply for this job?')) {
                    // Create a form to submit application
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = 'apply_job.php';

                    const jobIdInput = document.createElement('input');
                    jobIdInput.type = 'hidden';
                    jobIdInput.name = 'job_id';
                    jobIdInput.value = jobId;

                    form.appendChild(jobIdInput);
                    document.body.appendChild(form);
                    form.submit();
                }
            <?php endif; ?>
        }

        // View job details
        function viewJob(jobId) {
            window.location.href = 'view_job.php?id=' + jobId;
        }
    </script>
</body>
</html>
