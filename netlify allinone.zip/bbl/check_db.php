<?php
require 'config.php';

echo "<h2>Database Connection Test</h2>";

try {
    // Test connection
    $test = $conn->query("SELECT 1");
    echo "<p style='color: green;'>✓ Database connection successful!</p>";
    
    // Check existing tables
    echo "<h3>Existing Tables:</h3>";
    $tables = $conn->query("SHOW TABLES");
    $tableList = $tables->fetchAll(PDO::FETCH_COLUMN);
    
    if (count($tableList) > 0) {
        echo "<ul>";
        foreach ($tableList as $table) {
            echo "<li>$table</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>No tables found!</p>";
    }
    
    // Check if jobs table exists
    echo "<h3>Jobs Table Status:</h3>";
    $checkJobs = $conn->query("SHOW TABLES LIKE 'jobs'");
    if ($checkJobs->rowCount() > 0) {
        echo "<p style='color: green;'>✓ Jobs table EXISTS</p>";
        
        // Show jobs table structure
        echo "<h4>Jobs Table Columns:</h4>";
        $columns = $conn->query("SHOW COLUMNS FROM jobs");
        $colList = $columns->fetchAll(PDO::FETCH_ASSOC);
        echo "<ul>";
        foreach ($colList as $col) {
            echo "<li>" . $col['Field'] . " (" . $col['Type'] . ")</li>";
        }
        echo "</ul>";
    } else {
        echo "<p style='color: red;'>✗ Jobs table DOES NOT exist</p>";
        echo "<p><strong>Solution:</strong> <a href='setup.php'>Click here to create it automatically</a></p>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>✗ Database connection failed: " . $e->getMessage() . "</p>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Database Check</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f5f7fb;
        }
        a {
            background-color: #3a86ff;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>
</body>
</html>
