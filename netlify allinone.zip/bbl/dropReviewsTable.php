<?php
require_once 'config.php';

try {
    $sql = "DROP TABLE IF EXISTS reviews";
    $conn->exec($sql);
    echo "Reviews table dropped successfully!\n";
} catch (PDOException $e) {
    echo "Error dropping reviews table: " . $e->getMessage() . "\n";
}
?>
