<?php
session_start();

// Delete freelancer profile (owner only)
$host = "localhost";
$db   = "workdb";
$user = "root";
$pass = "";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Database connection failed");
}

$current_user = $_SESSION['user_id'] ?? null;
if (!$current_user) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: findFreelancer.php");
    exit();
}

$stmt = $conn->prepare("SELECT * FROM freelancers WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
if (!$row) {
    header("Location: findFreelancer.php");
    exit();
}

if (intval($row['user_id']) !== intval($current_user)) {
    echo "You are not authorized to delete this profile.";
    exit();
}

// Delete avatar file if it exists and is not data URI
$avatar = $row['avatar'] ?? '';
if ($avatar && strpos($avatar, 'data:image') !== 0 && file_exists(__DIR__ . '/' . $avatar)) {
    @unlink(__DIR__ . '/' . $avatar);
}

$del = $conn->prepare("DELETE FROM freelancers WHERE id = ?");
$del->bind_param("i", $id);
$del->execute();

header("Location: indexLog.php");
exit();
