<?php
session_start();

// Basic send message handler; only businesses may send messages to freelancers
$host = "localhost";
$db   = "workdb";
$user = "root";
$pass = "";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Database connection failed");
}

$current_user = $_SESSION['user_id'] ?? null;
if (!$current_user) {
    header("Location: login.php");
    exit();
}

$roleQ = $conn->prepare("SELECT role, email FROM users WHERE id = ?");
$roleQ->bind_param("i", $current_user);
$roleQ->execute();
$roleR = $roleQ->get_result();
$roleData = $roleR->fetch_assoc();
if (!$roleData || $roleData['role'] !== 'business') {
    echo "Only business accounts can message freelancers.";
    exit();
}

$freelancer_id = $_GET['id'] ?? $_POST['id'] ?? null;
if (!$freelancer_id) {
    header("Location: findFreelancer.php");
    exit();
}

// Try to fetch freelancer contact info (if from DB)
$freelancer = null;
$stmt = $conn->prepare("SELECT f.*, u.email FROM freelancers f LEFT JOIN users u ON f.user_id = u.id WHERE f.id = ?");
$stmt->bind_param("i", $freelancer_id);
$stmt->execute();
$res = $stmt->get_result();
if ($res && $res->num_rows > 0) {
    $freelancer = $res->fetch_assoc();
}

// If hardcoded or no DB entry, proceed with minimal info



?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Contact Freelancer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Oswald', Arial, Helvetica, sans-serif;
            padding: 20px;
            background: #f5f7fb;
            line-height: 1.6;
        }
        
        .box {
            max-width: 700px;
            margin: 0 auto;
            background: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.08);
        }
        
        h2 {
            color: #212529;
            margin-bottom: 10px;
            font-size: 1.8rem;
        }
        
        .subtitle {
            color: #6c757d;
            margin-bottom: 30px;
            font-size: 0.95rem;
        }
        
        .email-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            border-left: 4px solid #3a86ff;
        }
        
        .email-label {
            color: #6c757d;
            font-size: 0.9rem;
            margin-bottom: 8px;
        }
        
        .email-display {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
        }
        
        .email-text {
            font-weight: 600;
            color: #3a86ff;
            font-size: 1.1rem;
            word-break: break-all;
            flex: 1;
        }
        
        .copy-btn {
            background: linear-gradient(135deg, #3a86ff, #1b63e8);
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            white-space: nowrap;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .copy-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(58, 134, 255, 0.3);
        }
        
        .copy-btn:active {
            transform: translateY(0);
        }
        
        label {
            display: block;
            margin: 20px 0 8px 0;
            font-weight: 700;
            color: #212529;
        }
        
        input,
        textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-family: 'Oswald', Arial, sans-serif;
            font-size: 16px;
        }
        
        input:focus,
        textarea:focus {
            outline: none;
            border-color: #3a86ff;
            box-shadow: 0 0 5px rgba(58, 134, 255, 0.3);
        }
        
        textarea {
            resize: vertical;
            min-height: 120px;
        }
        
        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        button[type="submit"] {
            background: linear-gradient(135deg, #38b000, #2d9a00);
            color: #fff;
            border: none;
            padding: 12px 30px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-family: 'Oswald', Arial, sans-serif;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
            flex: 1;
            justify-content: center;
        }
        
        button[type="submit"]:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(56, 176, 0, 0.3);
        }
        
        .back-btn {
            background: #6c757d;
            color: #fff;
            border: none;
            padding: 12px 30px;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .back-btn:hover {
            background: #5a6268;
            transform: translateY(-2px);
        }
        
        @media (max-width: 600px) {
            .box {
                padding: 20px;
            }
            
            .button-group {
                flex-direction: column;
            }
            
            .email-display {
                flex-direction: column;
                align-items: stretch;
            }
            
            .copy-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
<div class="box">
    <h2>Contact Freelancer</h2>
    <p class="subtitle">Copy the freelancer's email to reach out to them directly</p>
    
    <!-- Email Copy Section -->
    <div class="email-section">
        <div class="email-label">Freelancer Email Address:</div>
        <div class="email-display">
            <div class="email-text" id="emailText"><?php echo htmlspecialchars($freelancer['name'] ?? 'Freelancer'); ?> - Email available after copying</div>
            <button type="button" class="copy-btn" onclick="copyEmail()">
                <i class="fas fa-copy"></i> Copy Email
            </button>
        </div>
    </div>
    
    <!-- Send Email Button -->
    <div class="button-group">
        <button type="button" onclick="sendEmail()"><i class="fas fa-envelope"></i> Send Email</button>
        <a href="findFreelancer.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back</a>
    </div>
</div>

<script>
    const freelancerEmail = '<?php 
        // Try to get freelancer email from database
        $freelancerEmail = $freelancer['email'] ?? 'contact@freelancer.com';
        echo htmlspecialchars($freelancerEmail);
    ?>';
    
    const freelancerName = '<?php echo htmlspecialchars($freelancer['name'] ?? 'Freelancer'); ?>';

    function copyEmail() {
        // Copy email to clipboard
        navigator.clipboard.writeText(freelancerEmail).then(() => {
            // Update display
            document.getElementById('emailText').textContent = freelancerEmail;
            showNotification('Email copied to clipboard!', 'success');
        }).catch(() => {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = freelancerEmail;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);

            document.getElementById('emailText').textContent = freelancerEmail;
            showNotification('Email copied to clipboard!', 'success');
        });
    }

    function sendEmail() {
        // Copy email to clipboard
        copyEmail();
        // Open default email client
        window.location.href = 'mailto:' + freelancerEmail;
    }

    function showNotification(message, type = 'success') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'notification ' + type;
        notification.innerHTML = `
            <i class="fas fa-check-circle"></i>
            ${message}
        `;
        
        // Add styles
        const style = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#38b000' : '#e63946'};
            color: white;
            padding: 16px 24px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 600;
            z-index: 1000;
            animation: slideIn 0.3s ease-out;
            font-family: 'Oswald', Arial, sans-serif;
        `;
        notification.setAttribute('style', style);
        
        document.body.appendChild(notification);
        
        // Auto-remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease-out';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    // Add animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(400px);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
</script>
</body>
</html>
