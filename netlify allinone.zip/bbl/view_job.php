<?php
session_start();
require 'config.php';

// No role restriction: allow anyone (logged in or not) to view job details

// Get job ID from URL
$job_id = $_GET['id'] ?? null;

if (!$job_id) {
    header("Location: jobs.php");
    exit();
}

// Fetch job from database
$stmt = $conn->prepare("SELECT j.*, u.email, u.username FROM jobs j LEFT JOIN users u ON j.user_id = u.id WHERE j.id = ?");
$stmt->execute([$job_id]);
$job = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$job) {
    header("Location: jobs.php");
    exit();
}

// Process skills
$skills = $job['skills_required'] ? array_filter(array_map('trim', explode(',', $job['skills_required']))) : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($job['job_title']); ?> - Find Jobs</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Oswald", sans-serif;
            background-color: #f5f7fb;
            color: #212529;
            line-height: 1.6;
        }

        :root {
            --primary-color: #3a86ff;
            --secondary-color: #8338ec;
            --accent-color: #ff006e;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --gray-color: #6c757d;
            --success-color: #38b000;
        }

        .container {
            width: 100%;
            max-width: 900px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header */
        header {
            background-color: white;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--primary-color);
            text-decoration: none;
        }

        .logo span {
            color: var(--secondary-color);
        }

        nav ul {
            display: flex;
            list-style: none;
            gap: 30px;
        }

        nav a {
            text-decoration: none;
            color: var(--dark-color);
            font-weight: 500;
            transition: color 0.3s;
        }

        nav a:hover {
            color: var(--primary-color);
        }

        .job-details-container {
            background: white;
            margin: 30px auto;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        .job-header {
            margin-bottom: 30px;
            border-bottom: 2px solid #e9ecef;
            padding-bottom: 20px;
        }

        .job-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 10px;
            color: var(--dark-color);
        }

        .job-meta {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
            font-size: 1rem;
            color: var(--gray-color);
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .meta-item i {
            color: var(--primary-color);
            font-size: 1.2rem;
        }

        .job-salary {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--secondary-color);
            margin-top: 15px;
        }

        .section {
            margin-bottom: 30px;
        }

        .section-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 15px;
            color: var(--dark-color);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title i {
            color: var(--primary-color);
        }

        .description {
            color: #555;
            line-height: 1.8;
            white-space: pre-wrap;
        }

        .skills-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .skill-tag {
            background: #e8f0ff;
            color: var(--primary-color);
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .action-buttons {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #e9ecef;
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-family: "Oswald", sans-serif;
            font-size: 1rem;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(58, 134, 255, 0.3);
        }

        .btn-contact {
            background: linear-gradient(135deg, #ff6b6b, #ff006e);
            color: white;
        }

        .btn-contact:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(255, 107, 107, 0.3);
        }

        .company-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .company-name {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 5px;
        }

        .company-contact {
            color: var(--gray-color);
            font-size: 0.95rem;
        }

        footer {
            background: #212529;
            color: white;
            text-align: center;
            padding: 30px 0;
            margin-top: 50px;
        }

        @media (max-width: 768px) {
            .job-title {
                font-size: 1.6rem;
            }

            .job-meta {
                flex-direction: column;
                gap: 15px;
            }

            .action-buttons {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }

            .job-details-container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <a href="indexlog.php" class="logo">
                    <i class="fas fa-briefcase"></i>
                    ALL<span>IN</span>ONE
                </a>
                <nav>
                    <ul>
                        <li><a href="indexlog.php">Home</a></li>
                        <li><a href="jobs.php">Jobs</a></li>
                        <li><a href="accsettings.php">Profile</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <!-- Job Details -->
    <div class="container">
        <div class="job-details-container">
            <a href="jobs.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Jobs</a>

            <div class="job-header">
                <h1 class="job-title"><?php echo htmlspecialchars($job['job_title']); ?></h1>
                <div class="company-info">
                    <div class="company-name"><?php echo htmlspecialchars($job['company_name']); ?></div>
                    <div class="company-contact">Posted by: <?php echo htmlspecialchars($job['username'] ?? 'Company'); ?></div>
                </div>
                <div class="job-meta">
                    <div class="meta-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <span><?php echo htmlspecialchars($job['location']); ?></span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-briefcase"></i>
                        <span><?php echo htmlspecialchars($job['job_type']); ?></span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-calendar-alt"></i>
                        <span><?php echo date('M d, Y', strtotime($job['created_at'])); ?></span>
                    </div>
                </div>
                <?php if ($job['salary_min'] && $job['salary_max']): ?>
                    <div class="job-salary">
                        $<?php echo number_format($job['salary_min']); ?> - $<?php echo number_format($job['salary_max']); ?> per year
                    </div>
                <?php elseif ($job['salary_min']): ?>
                    <div class="job-salary">
                        From $<?php echo number_format($job['salary_min']); ?> per year
                    </div>
                <?php else: ?>
                    <div class="job-salary">Competitive Salary</div>
                <?php endif; ?>
            </div>

            <!-- Description -->
            <div class="section">
                <div class="section-title">
                    <i class="fas fa-file-alt"></i>
                    Job Description
                </div>
                <div class="description"><?php echo htmlspecialchars($job['description']); ?></div>
            </div>

            <!-- Skills Required -->
            <?php if (count($skills) > 0): ?>
            <div class="section">
                <div class="section-title">
                    <i class="fas fa-star"></i>
                    Required Skills
                </div>
                <div class="skills-container">
                    <?php foreach ($skills as $skill): ?>
                        <div class="skill-tag"><?php echo htmlspecialchars($skill); ?></div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Action Buttons -->
            <div class="action-buttons">
                
                <button class="btn btn-contact" onclick="contactBusiness()">
                    <i class="fas fa-envelope"></i>
                    Contact Employer
                </button>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="container">
            <p>&copy; 2025 ALLINONE. All rights reserved.</p>
        </div>
    </footer>

    <script>
        const businessEmail = '<?php echo htmlspecialchars($job['email'] ?? 'contact@example.com'); ?>';
        const jobTitle = '<?php echo htmlspecialchars($job['job_title']); ?>';

        function applyForJob() {
            if (confirm('Are you sure you want to apply for this position?\n\n' + jobTitle + '\n\nYour application will be submitted to the employer.')) {
                // Create form to submit application
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'apply_job.php';

                const jobIdInput = document.createElement('input');
                jobIdInput.type = 'hidden';
                jobIdInput.name = 'job_id';
                jobIdInput.value = '<?php echo $job_id; ?>';

                form.appendChild(jobIdInput);
                document.body.appendChild(form);
                form.submit();
            }
        }

        function contactBusiness() {
            // Copy email to clipboard
            navigator.clipboard.writeText(businessEmail).then(() => {
                // Show notification
                showNotification('Email copied to clipboard!', 'success');
            }).catch(() => {
                // Fallback if clipboard API fails
                const textArea = document.createElement('textarea');
                textArea.value = businessEmail;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                showNotification('Email copied to clipboard!', 'success');
            });
        }

        function showNotification(message, type = 'success') {
            // Create notification element
            const notification = document.createElement('div');
            notification.className = 'notification ' + type;
            notification.innerHTML = `
                <i class="fas fa-check-circle"></i>
                ${message}
            `;
            
            // Add styles
            const style = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#38b000' : '#e63946'};
                color: white;
                padding: 16px 24px;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                display: flex;
                align-items: center;
                gap: 10px;
                font-weight: 600;
                z-index: 1000;
                animation: slideIn 0.3s ease-out;
            `;
            notification.setAttribute('style', style);
            
            document.body.appendChild(notification);
            
            // Auto-remove after 3 seconds
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease-out';
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 300);
            }, 3000);
        }

        // Add animations
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(400px);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            @keyframes slideOut {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(400px);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>
