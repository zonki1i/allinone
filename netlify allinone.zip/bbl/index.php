<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Google Font: Oswald (Variable) -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All in One - Freelancers, Full time, and B2B</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: "Oswald", sans-serif;
    font-optical-sizing: auto;
    font-style: normal;
}


        :root {
            --primary-color: #3a86ff;
            --secondary-color: #8338ec;
            --accent-color: #ff006e;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --gray-color: #6c757d;
            --success-color: #38b000;
        }

        body {
            line-height: 1.6;
            color: var(--dark-color);
            background-color: #f5f7fb;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header */
        header {
            background-color: #f5f7fb;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-color);
            text-decoration: none;
        }

        .logo span {
            color: var(--secondary-color);
        }

        .logo i {
            font-size: 2rem;
        }

        nav ul {
            display: flex;
            list-style: none;
            gap: 30px;
        }

        nav a {
            text-decoration: none;
            color: var(--dark-color);
            font-weight: 600;
            transition: color 0.3s;
        }

        nav a:hover {
            color: var(--primary-color);
        }

        .cta-button {
            background: linear-gradient(135deg, #3a86ff 0%, #1b63e8 100%);
            color: white;
            padding: 14px 35px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 800;
            font-size: 1rem;
            font-family: "Oswald", sans-serif;
            letter-spacing: 1px;
            transition: all 0.4s cubic-bezier(0.23, 1, 0.320, 1);
            box-shadow: 0 8px 25px rgba(58, 134, 255, 0.4);
            border: none;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
            display: inline-block;
        }

        .cta-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s ease;
            z-index: 1;
        }

        .cta-button::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.1) 0%, transparent 100%);
            pointer-events: none;
        }

        .cta-button:hover {
            transform: translateY(-3px) scale(1.08);
            box-shadow: 0 12px 35px rgba(58, 134, 255, 0.5);
            background: linear-gradient(135deg, #1b63e8 0%, #0d47a1 100%);
        }

        .cta-button:hover::before {
            left: 100%;
        }

        .cta-button:active {
            transform: translateY(-1px);
            box-shadow: 0 5px 15px rgba(58, 134, 255, 0.4);
        }

        .profile-dropdown {
            position: relative;
            display: inline-block;
        }

        .profile-btn {
            background: none;
            border: none;
            color: var(--dark-color);
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .profile-btn:hover {
            color: var(--primary-color);
        }

        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 5px;
        }

        .dropdown-content a {
            color: var(--dark-color);
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            font-weight: 500;
        }

        .dropdown-content a:hover {
            background-color: var(--light-color);
        }

        .profile-dropdown:hover .dropdown-content {
            display: block;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--dark-color);
            cursor: pointer;
        }

        /* Hero Section */
        .hero {
            padding: 80px 0;
            background: linear-gradient(135deg, #3a86ff 0%, #8338ec 100%);
            text-align: center;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            color: white;
        }

        .hero p {
            font-size: 1.2rem;
            color: rgba(255, 255, 255, 0.9);
            max-width: 700px;
            margin: 0 auto 40px;
        }

        .highlight {
            color: white;
            font-weight: 700;
        }

        /* Find It Fast Section */
        .find-fast {
            padding: 60px 0;
            text-align: center;
            background-color: white;
        }

        .find-fast h2 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: var(--dark-color);
        }

        .find-fast .subtitle {
            font-size: 1.2rem;
            color: var(--gray-color);
            margin-bottom: 40px;
        }

        .stats-container {
            display: flex;
            justify-content: center;
            gap: 50px;
            margin-top: 40px;
            flex-wrap: wrap;
        }

        .stat-box {
            background: linear-gradient(135deg, #f8f9fa 0%, #e3edff 100%);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            min-width: 200px;
        }

        .stat-box i {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: var(--primary-color);
        }

        .stat-box h3 {
            font-size: 2.5rem;
            color: var(--secondary-color);
            margin-bottom: 5px;
        }

        .stat-box p {
            color: var(--gray-color);
            font-weight: 600;
        }

        

        /* Who is it for Section */
        .who-for {
            padding: 80px 0;
            background: linear-gradient(135deg, #f8f9fa 0%, #e3edff 100%);
        }

        .who-for h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: var(--dark-color);
        }

        .who-for > p {
            text-align: center;
            color: var(--gray-color);
            font-size: 1.2rem;
            margin-bottom: 60px;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }

        .communities {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
            justify-content: center;
        }

        .community-card {
            flex: 1;
            min-width: 300px;
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s;
        }

        .community-card:hover {
            transform: translateY(-10px);
        }

        .card-header {
            padding: 25px;
            color: white;
            text-align: center;
        }

        .freelancers .card-header {
            background: linear-gradient(135deg, #3a86ff 0%, #8338ec 100%);
        }

        .job-seekers .card-header {
            background: linear-gradient(135deg, #8338ec 0%, #3a86ff 100%);
        }

        .businesses .card-header {
            background: linear-gradient(135deg, #8338ec 0%, #ff006e 100%);
        }

        .card-header h3 {
            font-size: 1.8rem;
            margin-bottom: 10px;
        }

        .card-body {
            padding: 30px;
        }

        .card-body p {
            color: var(--gray-color);
            margin-bottom: 20px;
        }

        .card-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: transparent;
            border: 2px solid;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }

        .freelancers .card-button {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .job-seekers .card-button {
            color: var(--secondary-color);
            border-color: var(--secondary-color);
        }

        .businesses .card-button {
            color: var(--accent-color);
            border-color: var(--accent-color);
        }

        .card-button:hover {
            color: white;
        }

        .freelancers .card-button:hover {
            background-color: var(--primary-color);
        }

        .job-seekers .card-button:hover {
            background-color: var(--secondary-color);
        }

        .businesses .card-button:hover {
            background-color: var(--accent-color);
        }

        /* Platform Section */
        .platform {
            padding: 60px 0;
            background-color: white;
            text-align: center;
        }

        .platform h2 {
            font-size: 2.5rem;
            margin-bottom: 40px;
            color: var(--dark-color);
        }

        .platform-features {
            display: flex;
            justify-content: center;
            gap: 50px;
            flex-wrap: wrap;
        }

        .feature {
            flex: 1;
            min-width: 250px;
            max-width: 300px;
        }

        .feature i {
            font-size: 3rem;
            color: var(--primary-color);
            margin-bottom: 20px;
        }

        .feature h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .feature p {
            color: var(--gray-color);
        }

        /* Updated Footer Styles - BIGGER WAVE */
        /* Footer */
footer {
    position: relative;
    color: white;
    background-color: blue; /* Wave provides the color */
    overflow: hidden;
}

.footer-wave {
    position: absolute;
    top: -150px; /* Adjust to match wave size */
    left: 0;
    width: 100%;
    height: 150px;
    z-index: 1;
}

.footer-wave svg {
    width: 100%;
    height: 100%;
}

.footer-content-wrapper {
    position: relative;
    z-index: 2; /* Makes content appear above the SVG */
    padding: 60px 0 40px;
}

.footer-columns {
    display: flex;
    flex-wrap: wrap;
    gap: 50px;
    margin-bottom: 40px;
}

.footer-column {
    flex: 1;
    min-width: 200px;
}

.footer-column h3 {
    font-size: 1.3rem;
    margin-bottom: 20px;
    color: white;
}

.footer-column ul {
    list-style: none;
}

.footer-column ul li {
    margin-bottom: 10px;
}

.footer-column a {
    color: rgba(255, 255, 255, 0.8);
    text-decoration: none;
    transition: color 0.3s;
}

.footer-column a:hover {
    color: white;
}

.notice {
    background-color: rgba(255, 255, 255, 0.1);
    padding: 15px;
    border-radius: 5px;
    margin-top: 20px;
    font-size: 0.9rem;
    color: rgba(255, 255, 255, 0.8);
}

.copyright {
    text-align: center;
    padding-top: 30px;
    border-top: 1px solid rgba(255, 255, 255, 0.2);
    color: rgba(255, 255, 255, 0.8);
    font-size: 0.9rem;
}

/* Responsive */
@media (max-width: 992px) {
    .footer-columns {
        gap: 30px;
    }
    footer {
        padding-top: 120px;
    }
    .footer-wave {
        top: -120px;
        height: 120px;
    }
}

@media (max-width: 768px) {
    .footer-columns {
        flex-direction: column;
        gap: 40px;
    }
    .footer-column {
        min-width: 100%;
    }
    footer {
        padding-top: 100px;
    }
    .footer-wave {
        top: -100px;
        height: 100px;
    }
}


        @media (max-width: 768px) {
            .header-content {
                flex-wrap: wrap;
            }
            
            nav {
                display: none;
                width: 100%;
                order: 3;
                margin-top: 20px;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 15px;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            .hero h1 {
                font-size: 2rem;
            }
            
            .find-fast h2, .who-for h2, .platform h2 {
                font-size: 2rem;
            }
            
            .stats-container {
                flex-direction: column;
                align-items: center;
            }
            
            .footer-columns {
                flex-direction: column;
                gap: 40px;
            }
            
            .footer-column {
                min-width: 100%;
            }
            
            /* Adjust wave for mobile */
            footer {
                padding-top: 100px;
            }

            .spacer{
                aspect-ratio: 960/540;
                width: 100%;
                background-repeat: no-repeat;
                background-position: center;
                background-size: cover;
            }

            .layer1 {
                background-image: url ('img/wave.png');
            }
            
            .footer-wave {
                top: -100px;
                height: 100px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <a href="#" class="logo">
                    <i class="fas fa-briefcase"></i>
                    ALL<span>IN</span>ONE
                </a>
                
                <button class="mobile-menu-btn" id="mobileMenuBtn">
                    <i class="fas fa-bars"></i>
                </button>
                
                <nav id="mainNav">
                    <ul>
                       <li><a href="freelancing.php">Freelancers</a></li>
                        <li><a href="jobs.php">Jobs</a></li>
                        <li><a href="hire.php">Hire</a></li>
                        <li><a href="reviews.php">Reviews</a></li>
                    </ul>
                </nav>
                
                <a href="signUp.php" class="cta-button">Get Started</a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Marketplace for <span class="highlight">freelancers</span>, <span class="highlight">full-time</span>, and <span class="highlight">B2B</span></h1>
            <p>Connect, collaborate, and succeed with our platform that brings together three distinct communities to help you find what you need faster than ever.</p>
            <a href="#find-fast" class="cta-button">Explore Now</a>
        </div>
    </section>

    <!-- Find It Fast Section -->
    <section class="find-fast" id="find-fast">
        <div class="container">
            <h2>Find It Fast</h2>
            <p class="subtitle">If it takes more than 7 seconds, it's too slow.</p>
            
            <div class="stats-container">
                <div class="stat-box">
                    <i class="fas fa-users"></i>
                    <h3>151</h3>
                    <p>PEOPLE</p>
                </div>
                
                <div class="stat-box">
                    <i class="fas fa-building"></i>
                    <h3>43</h3>
                    <p>BUSINESSES</p>
                </div>
                
                <div class="stat-box">
                    <i class="fas fa-briefcase"></i>
                    <h3>87</h3>
                    <p>JOBS</p>
                </div>
            </div>
            
            
        </div>
    </section>

    <!-- Who is it for Section -->
    <section class="who-for" id="who-for">
        <div class="container">
            <h2>Who is it for?</h2>
            
            
            <div class="communities">
                <!-- Freelancers Card -->
                <div class="community-card freelancers">
                    <div class="card-header">
                        <h3>Freelancers</h3>
                    </div>
                    <div class="card-body">
                        <p>Hire freelancer or offer your skills as freelancer. Connect, collaborate, succeed.</p>
                        <a href="freelancing.php" class="card-button">Explore Freelancing</a>

                    </div>
                </div>
                
                <!-- Job Seekers Card -->
                <div class="community-card job-seekers">
                    <div class="card-header">
                        <h3>Jobs</h3>
                    </div>
                    <div class="card-body">
                        <p>Searching for full-time or part-time jobs that match your career goals.</p>
                        <a href="jobs.php" class="card-button">Find Jobs</a>
                    </div>
                </div>
                
                <!-- Businesses Card -->
                <div class="community-card businesses">
                    <div class="card-header">
                        <h3>Businesses</h3>
                    </div>
                    <div class="card-body">
                        <p>Find the right talent for your projects or discover B2B opportunities to grow your business.</p>
                        <a href="hire.php" class="card-button">For Businesses</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Platform Section -->
    <section class="platform" id="platform">
        <div class="container">
            <h2>Platform</h2>
            <div class="platform-features">
                <div class="feature">
                    <i class="fas fa-user-friends"></i>
                    <h3>People</h3>
                    <p>Connect with skilled professionals and find the perfect match for your project or team.</p>
                </div>
                
                <div class="feature">
                    <i class="fas fa-briefcase"></i>
                    <h3>Jobs</h3>
                    <p>Discover full-time, part-time, and freelance opportunities that align with your career path.</p>
                </div>
                
                <div class="feature">
                    <i class="fas fa-building"></i>
                    <h3>Businesses</h3>
                    <p>Find B2B services, partnerships, and resources to help your business thrive.</p>
                </div>
            </div>
        </div>
    </section>

    <div class="spacer layer1"></div>


<footer id="legal">
    

    <div class="container footer-content-wrapper">
        <div class="footer-columns">
            <!-- About Us -->
            <div class="footer-column">
                <h3>About Us</h3>
                <ul>
                    <li><a href="#">Our Mission</a></li>
                    <li><a href="#">Team</a></li>
                    <li><a href="#">Careers</a></li>
                    <li><a href="#">Press</a></li>
                </ul>
            </div>

            <!-- For Freelancers -->
            <div class="footer-column">
                <h3>For Freelancers</h3>
                <ul>
                    <li><a href="#">Find Projects</a></li>
                    <li><a href="#">Build Portfolio</a></li>
                    <li><a href="#">Freelancer Resources</a></li>
                    <li><a href="#">Community</a></li>
                </ul>
            </div>

            <!-- For Businesses -->
            <div class="footer-column">
                <h3>For Businesses</h3>
                <ul>
                    <li><a href="#">Hire Talent</a></li>
                    <li><a href="#">Post Projects</a></li>
                    <li><a href="#">B2B Services</a></li>
                    <li><a href="#">Enterprise Solutions</a></li>
                </ul>
            </div>

            <!-- Legal -->
            <div class="footer-column">
                <h3>Legal</h3>
                <ul>
                    <li><a href="#">Terms of Service</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Cookie Policy</a></li>
                    <li><a href="#">GDPR</a></li>
                </ul>
                <div class="notice">
                    <p>allinone.com is a platform connecting freelancers, job seekers, and businesses. We do not charge any commission fees.</p>
                </div>
            </div>
        </div>

        <div class="copyright">
            &copy; 2025 allinone.com. All rights reserved.
        </div>
    </div>
</footer>



    <script>
    // Mobile menu toggle
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mainNav = document.getElementById('mainNav');

    mobileMenuBtn.addEventListener('click', () => {
        mainNav.classList.toggle('active');
        const icon = mobileMenuBtn.querySelector('i');
        icon.classList.toggle('fa-bars');
        icon.classList.toggle('fa-times');
    });

    // Smooth scrolling ONLY for real hash links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');

            if (targetId === '#') return; // allow normal click

            e.preventDefault();
            const target = document.querySelector(targetId);
            if (!target) return;

            window.scrollTo({
                top: target.offsetTop - 80,
                behavior: 'smooth'
            });
        });
    });
</script>

</body>
</html>