<?php
require 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

$usernameOrEmail = trim($_POST['username']);
$password = $_POST['password'];

try {
    $stmt = $conn->prepare(
        "SELECT id, username, password FROM users WHERE username = :username OR email = :email"
    );
    
    $stmt->execute([
        ':username' => $usernameOrEmail,
        ':email' => $usernameOrEmail
    ]);
    
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        header('Location: login.php?error=invalid');
        exit;
    }
    
    if (!password_verify($password, $user['password'])) {
        header('Location: login.php?error=invalid');
        exit;
    }
    
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    
    header('Location: indexlog.php');
    exit;
    
} catch (PDOException $e) {
    header('Location: login.php?error=database');
    exit;
}