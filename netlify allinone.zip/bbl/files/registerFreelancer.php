<?php
session_start();

// register-freelancer.php

// DB CONNECTION (edit credentials)
$host = "localhost";
$db   = "workdb";
$user = "root";
$pass = "";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Database connection failed");
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if user has freelancer role
$user_id = $_SESSION['user_id'];
$user_query = $conn->prepare("SELECT role FROM users WHERE id = ?");
$user_query->bind_param("i", $user_id);
$user_query->execute();
$user_result = $user_query->get_result();
$user_data = $user_result->fetch_assoc();

if (!$user_data || $user_data['role'] !== 'freelancer') {
    // Show alert and redirect
    echo "<script>
        alert('You\\'re not a freelancer! To change this, go to the Account Settings page located by clicking the Profile icon in the top right.');
        window.location.href = 'indexLog.php';
    </script>";
    exit();
}

// Prevent creating more than one freelancer profile per user
$existingCheck = $conn->prepare("SELECT id FROM freelancers WHERE user_id = ?");
$existingCheck->bind_param("i", $user_id);
$existingCheck->execute();
$existingRes = $existingCheck->get_result();
if ($existingRes && $existingRes->num_rows > 0) {
    $row = $existingRes->fetch_assoc();
    header("Location: editFreelancer.php?id=" . $row['id']);
    exit();
}

$message = null;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name           = trim($_POST['name']);
    $surname        = trim($_POST['surname']);
    $specialty      = trim($_POST['specialty']);
    $country        = trim($_POST['country']);
    $price_per_hour = trim($_POST['price_per_hour']);
    $skills         = trim($_POST['skills']);
    $extra_info     = trim($_POST['extra_info']);
    
    // Handle profile picture upload
    $profile_pic = '';
    if (!empty($_FILES['profile_picture']['name'])) {
        $upload_dir = 'uploads/profiles/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_name = basename($_FILES['profile_picture']['name']);
        $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array(strtolower($file_ext), $allowed_ext)) {
            $new_file_name = $user_id . '_' . time() . '.' . $file_ext;
            $upload_path = $upload_dir . $new_file_name;
            
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $upload_path)) {
                $profile_pic = $upload_path;
            } else {
                $profile_pic = '';
            }
        } else {
            $profile_pic = '';
        }
    }
    
    // If no file uploaded, create avatar with first letter
    if (empty($profile_pic)) {
        $first_letter = strtoupper($name[0]);
        $colors = ['3a86ff', '8338ec', 'ff006e', 'fb5607', 'ffbe0b'];
        $color_index = (ord($first_letter) % count($colors));
        $bg_color = $colors[$color_index];
        $profile_pic = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='150' height='150'%3E%3Crect fill='%23{$bg_color}' width='150' height='150'/%3E%3Ctext x='50%25' y='50%25' font-size='60' font-weight='bold' fill='white' text-anchor='middle' dy='.3em' font-family='Arial'%3E{$first_letter}%3C/text%3E%3C/svg%3E";
    }

    // Insert freelancer profile
    $stmt = $conn->prepare("INSERT INTO freelancers (user_id, name, surname, specialty, country, price, skills, additional, avatar) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssdsss", $user_id, $name, $surname, $specialty, $country, $price_per_hour, $skills, $extra_info, $profile_pic);
    
    if ($stmt->execute()) {
        // Redirect to home page with success message
        header("Location: indexLog.php?freelancer_success=1");
        exit();
    } else {
        $message = "Error creating profile. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Freelancer</title>
    <!-- Google Font: Oswald (Variable) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <style>
        :root {
            --blue: #3a86ff;
            --blue-dark: #2f6fe0;
            --light: #f5f7fb;
            --dark: #212529;
            --gray: #6c757d;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--light);
            font-family: "Oswald", sans-serif;
            color: var(--dark);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 60px 20px;
        }

        .back-btn {
    display: inline-block;
    margin-bottom: 30px;
    padding: 10px 20px;
    background: linear-gradient(135deg, #3a86ff, #8338ec);
    color: white;
    border-radius: 30px;
    text-decoration: none;
    font-weight: 600;

    /* Smooth animation */
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.back-btn:hover {
    transform: scale(1.08) translateX(-5px);
    box-shadow: 0 8px 20px rgba(58, 134, 255, 0.3);
}

        .content-wrapper {
            display: flex;
            align-items: flex-start;
            justify-content: center;
            gap: 60px;
            margin-bottom: 40px;
            flex-wrap: wrap;
        }

        .image-section {
            flex: 1;
            min-width: 300px;
            text-align: center;
        }

        .image-section img {
            max-width: 100%;
            height: 730px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            object-fit: cover;
        }

        .form-box {
            background: white;
            padding: 40px;
            width: 100%;
            max-width: 450px;
            border-radius: 12px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }

        h1 {
            font-size: 2.5rem;
            margin-bottom: 15px;
            text-align: center;
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #3a86ff;
        }

        p.subtitle {
            color: var(--gray);
            margin-bottom: 50px;
            font-size: 1.1rem;
            text-align: center;
        }

        input, textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid #ddd;
            font-size: 1rem;
            font-family: 'Segoe UI', sans-serif;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #3a86ff;
            color: white;
            border: none;
            border-radius: 30px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
        }

        button:hover {
            background: #2f6fe0;
        }

        .msg {
            text-align: center;
            margin-top: 15px;
            color: #555;
            padding: 12px;
            background: #e7f3ff;
            border-radius: 8px;
        }

        .benefits {
            margin-top: 80px;
            padding-top: 60px;
            border-top: 2px solid #e0e0e0;
        }

        .benefits h3 {
            font-size: 2rem;
            margin-bottom: 40px;
            text-align: center;
        }

        .benefits-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }

        .benefit-item {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            text-align: center;
        }

        .benefit-item i {
            font-size: 2.5rem;
            color: #8338ec;
            margin-bottom: 15px;
        }

        .benefit-item h4 {
            margin-bottom: 10px;
            font-size: 1.1rem;
        }

        .benefit-item p {
            color: var(--gray);
            font-size: 0.95rem;
        }

        @media (max-width: 768px) {
            h1 { font-size: 2rem; }
            .content-wrapper { gap: 30px; }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<div class="container">
    <a href="freelancinglog.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back</a>
    
    <h1>Create Your Freelancer Profile</h1>
    <p class="subtitle">Start your journey and connect with clients worldwide</p>

    <div class="content-wrapper">
        <div class="image-section">
            <img src="https://www.4cornerresources.com/wp-content/uploads/2025/07/freelancer-looking-for-work.png" alt="Freelancer">
        </div>

        <div class="form-box">
            <h2>Freelancer Registration</h2>
            <form method="POST" enctype="multipart/form-data">
                <input type="text" name="name" placeholder="First Name" required>
                <input type="text" name="surname" placeholder="Last Name" required>
                <input type="text" name="specialty" placeholder="Your Specialty (e.g., Web Development)" required>
                <input type="text" name="country" placeholder="Country" required>
                <input type="number" name="price_per_hour" placeholder="Price per Hour ($)" step="0.01" required>
                <input type="text" name="skills" placeholder="Skills (comma-separated)" required>
                <input type="file" name="profile_picture" accept="image/jpeg,image/png,image/gif">
                <textarea name="extra_info" placeholder="Additional Information..."></textarea>
                <button type="submit">Create Profile</button>
            </form>

            <?php if ($message !== null): ?>
                <div class="msg"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>
        </div>
    </div>

    <div class="benefits">
        <h3>Get Started as a Freelancer</h3>
        <div class="benefits-grid">
            <div class="benefit-item">
                <i class="fas fa-chart-line"></i>
                <h4>Grow Your Business</h4>
                <p>Access thousands of potential clients and projects that match your skills.</p>
            </div>
            <div class="benefit-item">
                <i class="fas fa-clock"></i>
                <h4>Work Flexibly</h4>
                <p>Choose your own hours and work on projects that interest you most.</p>
            </div>
            <div class="benefit-item">
                <i class="fas fa-wallet"></i>
                <h4>Earn More</h4>
                <p>Set your own rates and keep full control of your pricing strategy.</p>
            </div>
            <div class="benefit-item">
                <i class="fas fa-users"></i>
                <h4>Build Your Network</h4>
                <p>Connect with clients and other professionals in your industry.</p>
            </div>
        </div>
    </div>
</div>

</body>
</html>
