<?php
session_start();

// Database connection
$host = "localhost";
$db   = "workdb";
$user = "root";
$pass = "";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Database connection failed");
}

// Fetch freelancers from database
$result = $conn->query("SELECT id, name, surname, specialty, country, price, skills, avatar, additional FROM freelancers");
$databaseFreelancers = [];

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $databaseFreelancers[] = [
            'id' => $row['id'],
            'name' => $row['name'] . ' ' . $row['surname'],
            'title' => $row['specialty'],
            'country' => $row['country'],
            'rate' => '$' . $row['price'] . '/hr',
            'skills' => array_filter(array_map('trim', explode(',', $row['skills']))),
            'avatar' => !empty($row['avatar']) ? $row['avatar'] : 'https://via.placeholder.com/150?text=No+Picture'
        ];
    }
}

// Hardcoded freelancers
$hardcodedFreelancers = [
    [
        'id' => -9,
        'name' => 'Jeffrey Epstein',
        'title' => 'Cybersecurity Consultant',
        'country' => 'United States',
        'rate' => '$60/hr',
        'skills' => ['Pen Testing', 'Security Audits'],
        'avatar' => 'https://upload.wikimedia.org/wikipedia/commons/6/62/Jeffrey_Epstein_mug_shot.jpg'
    ],
    [
        'id' => -12,
        'name' => 'Benjamin Netanyahu',
        'title' => 'AI Engineer',
        'country' => 'Israel',
        'rate' => '$70/hr',
        'skills' => ['Python', 'TensorFlow', 'Leadership'],
        'avatar' => 'https://upload.wikimedia.org/wikipedia/commons/1/1c/Benjamin_Netanyahu_2019_%28cropped%29.jpg'
    ]
];

// Merge hardcoded and database freelancers
$freelancers = array_merge($hardcodedFreelancers, $databaseFreelancers);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Find Freelancers</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
    --blue: #3a86ff;
    --blue-dark: #2f6fe0;
    --purple: #8338ec;
    --light: #f5f7fb;
    --dark: #212529;
    --gray: #6c757d;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: "Oswald", sans-serif;
}

body {
    font-family: "Oswald", sans-serif;
    background: var(--light);
    color: var(--dark);
}

.container {
    max-width: 1200px;
    margin: auto;
    padding: 40px 20px;
}

h1 {
    font-size: 2.5rem;
    margin-bottom: 30px;
    text-align: center;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 40px;
    flex-wrap: wrap;
    gap: 20px;
}

.back-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    background: linear-gradient(135deg, var(--blue), var(--purple));
    color: white;
    border-radius: 30px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s;
}

.back-btn:hover {
    transform: translateX(-5px);
    box-shadow: 0 8px 20px rgba(58, 134, 255, 0.3);
}

.grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 25px;
}

.card {
    background: white;
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card:hover {
    transform: translateY(-6px);
    box-shadow: 0 15px 35px rgba(0,0,0,0.12);
}

.avatar {
    width: 70px;
    height: 70px;
    border-radius: 50%;
    object-fit: cover;
    margin-bottom: 15px;
    border: 3px solid var(--light);
}

.name {
    font-size: 1.1rem;
    font-weight: 700;
    margin-bottom: 5px;
}

.title {
    font-size: 0.95rem;
    color: var(--gray);
    margin-bottom: 8px;
}

.country {
    font-size: 0.9rem;
    color: var(--blue);
    font-weight: 600;
    margin-bottom: 12px;
}

.rate {
    font-size: 1rem;
    font-weight: 700;
    color: var(--dark);
    margin-bottom: 12px;
}

.skills {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-bottom: 16px;
}

.skill {
    background: #e8efff;
    color: var(--blue);
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 500;
}

.btn {
    display: inline-block;
    padding: 10px 18px;
    background: var(--blue);
    color: white;
    border-radius: 8px;
    text-decoration: none;
    font-size: 0.95rem;
    font-weight: 600;
    transition: background 0.3s;
    width: 100%;
    text-align: center;
}

.btn:hover {
    background: var(--blue-dark);
}

@media (max-width: 768px) {
    h1 {
        font-size: 2rem;
    }
    
    .header {
        flex-direction: column;
        justify-content: flex-start;
    }
    
    .grid {
        grid-template-columns: 1fr;
    }
}

@media (min-width: 480px) and (max-width: 768px) {
    .grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

/* Back arrow style for the home button */
.back-btn::before {
    content: "\f060";
    font-family: 'Font Awesome 6 Free';
    font-weight: 600;
}
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>All Freelancers</h1>
        <a href="index.php" class="back-btn">Back to Home</a>
    </div>
    <div class="grid">
<?php foreach ($freelancers as $f): ?>
    <div class="card">
        <img class="avatar" src="<?= htmlspecialchars($f['avatar']) ?>" alt="">
        <div class="name"><?= htmlspecialchars($f['name']) ?></div>
        <div class="title"><?= htmlspecialchars($f['title']) ?></div>
        <div class="country"><?= htmlspecialchars($f['country']) ?></div>
        <div class="rate"><?= htmlspecialchars($f['rate']) ?></div>
        <div class="skills">
            <?php foreach ($f['skills'] as $skill): ?>
                <span class="skill"><?= htmlspecialchars($skill) ?></span>
            <?php endforeach; ?>
        </div>
        <a href="freelancer_profile.php?id=<?php echo $f['id']; ?>" class="btn">View Profile</a>
    </div>
<?php endforeach; ?>
</div>
</div>

<script>
// Optional: Add JavaScript for a back button that uses browser history
// This will make the back arrow work even if there's a previous page
document.addEventListener('DOMContentLoaded', function() {
    const backButton = document.querySelector('.btn-home');
    
    // Add click event to go back in history if there's history
    backButton.addEventListener('click', function(e) {
        // If we have previous page in history, use it
        if (window.history.length > 1) {
            // Optional: Check if we came from another page on the same site
            e.preventDefault();
            window.history.back();
        }
        // Otherwise, the href="index.php" will work normally
    });
    
    // Add keyboard shortcut (Alt + Left Arrow) for going back
    document.addEventListener('keydown', function(e) {
        if (e.altKey && e.key === 'ArrowLeft') {
            e.preventDefault();
            backButton.click();
        }
    });
});
</script>

</body>
</html>