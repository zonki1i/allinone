<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Freelancing | AllInOne</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --blue: #3a86ff;
            --blue-dark: #2f6fe0;
            --light: #f5f7fb;
            --dark: #212529;
            --gray: #6c757d;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: "Oswald", sans-serif;
        }

        body {
            background-color: var(--light);
            color: var(--dark);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 60px 20px;
        }

        .content-wrapper {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 60px;
            margin-bottom: 40px;
            flex-wrap: wrap;
        }

        .image-section {
            flex: 1;
            min-width: 300px;
            text-align: center;
        }

        .image-section img {
            max-width: 100%;
            height: auto;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .text-section {
            flex: 1;
            min-width: 300px;
        }

        h1 {
            font-size: 2.5rem;
            margin-bottom: 15px;
            text-align: center;
        }

        p.subtitle {
            color: var(--gray);
            margin-bottom: 50px;
            font-size: 1.1rem;
            text-align: center;
        }

        .options {
            display: flex;
            gap: 40px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .option-card {
            background-color: white;
            border-radius: 12px;
            padding: 40px 30px;
            width: 320px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .option-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.12);
        }

        .option-card i {
            font-size: 3rem;
            color: var(--blue);
            margin-bottom: 20px;
        }

        .option-card h2 {
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .option-card p {
            color: var(--gray);
            margin-bottom: 25px;
        }

        .btn {
            display: inline-block;
            padding: 12px 28px;
            background-color: var(--blue);
            color: white;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: var(--blue-dark);
        }

        .back-btn {
            display: inline-block;
            margin-bottom: 30px;
            padding: 10px 20px;
            background: linear-gradient(135deg, #3a86ff, #8338ec);
            color: white;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
            align-self: flex-start;
        }

        .back-btn:hover {
            transform: translateX(-5px);
            box-shadow: 0 8px 20px rgba(58, 134, 255, 0.3);
        }

        .features {
            margin-top: 80px;
            padding-top: 60px;
            border-top: 2px solid #e0e0e0;
        }

        .features h3 {
            font-size: 2rem;
            margin-bottom: 40px;
            text-align: center;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }

        .feature-item {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            text-align: center;
        }

        .feature-item i {
            font-size: 2.5rem;
            color: #8338ec;
            margin-bottom: 15px;
        }

        .feature-item h4 {
            margin-bottom: 10px;
            font-size: 1.1rem;
        }

        .feature-item p {
            color: var(--gray);
            font-size: 0.95rem;
        }

        @media (max-width: 768px) {
            h1 { font-size: 2rem; }
            .options { gap: 25px; }
            .content-wrapper { gap: 30px; }
            .image-section, .text-section { min-width: 100%; }
        }
    </style>
</head>
<body>

    <div class="container">
        <a href="<?php echo isset($_SESSION['user_id']) ? 'indexlog.php' : 'index.php'; ?>" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Home</a>
        
        <h1>Freelancing Platform</h1>
        <p class="subtitle">Connect with talented professionals or showcase your skills</p>

        <div class="content-wrapper">
            <div class="image-section">
                <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?w=500&h=500&fit=crop" alt="Freelancing">
            </div>

            <div class="text-section">
                <div class="options">
                    <!-- Register as Freelancer -->
                    <div class="option-card">
                        <i class="fas fa-user-plus"></i>
                        <h2>Register as a Freelancer</h2>
                        <p>Create your profile, showcase your skills, and start getting hired.</p>
                        <a href="registerFreelancer.php" class="btn">Get Started</a>
                    </div>

                    <!-- Find a Freelancer -->
                    <div class="option-card">
                        <i class="fas fa-search"></i>
                        <h2>Find a Freelancer</h2>
                        <p>Browse skilled freelancers and hire the right talent for your project.</p>
                        <a href="findFreelancer.php" class="btn">Find Talent</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="features">
            <h3>Why Choose Our Platform?</h3>
            <div class="features-grid">
                <div class="feature-item">
                    <i class="fas fa-shield-alt"></i>
                    <h4>Secure & Verified</h4>
                    <p>All freelancers and clients are verified for your peace of mind.</p>
                </div>
                <div class="feature-item">
                    <i class="fas fa-star"></i>
                    <h4>Quality Reviews</h4>
                    <p>Real ratings and reviews from actual clients and freelancers.</p>
                </div>
                <div class="feature-item">
                    <i class="fas fa-dollar-sign"></i>
                    <h4>Competitive Rates</h4>
                    <p>Find talent that fits your budget and quality requirements.</p>
                </div>
                <div class="feature-item">
                    <i class="fas fa-headset"></i>
                    <h4>24/7 Support</h4>
                    <p>Get help whenever you need it. We're always here for you.</p>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
