<?php
require 'config.php';

try {
    // Check if jobs table exists
    $checkTable = $conn->query("SHOW TABLES LIKE 'jobs'");
    if ($checkTable->rowCount() == 0) {
        // Create jobs table
        $sql = "CREATE TABLE IF NOT EXISTS jobs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            job_title VARCHAR(255) NOT NULL,
            company_name VARCHAR(255) NOT NULL,
            description TEXT NOT NULL,
            salary_min DECIMAL(10, 2),
            salary_max DECIMAL(10, 2),
            job_type VARCHAR(50) NOT NULL,
            location VARCHAR(100) NOT NULL,
            skills_required TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        ) ENGINE=InnoDB";
        
        $conn->exec($sql);
        echo "<h2 style='color: green;'>✓ Jobs table created successfully!</h2>";
    } else {
        echo "<h2 style='color: blue;'>✓ Jobs table already exists!</h2>";
    }

    // Add user_id to reviews table if it doesn't exist
    $checkColumn = $conn->query("SHOW COLUMNS FROM reviews LIKE 'user_id'");
    if ($checkColumn->rowCount() == 0) {
        $conn->exec("ALTER TABLE reviews ADD COLUMN user_id INT DEFAULT NULL");
        echo "<p style='color: green;'>✓ Added user_id column to reviews table</p>";
    } else {
        echo "<p style='color: blue;'>✓ user_id column already exists in reviews table</p>";
    }

    // Create businesses table if it doesn't exist
    $checkBusinesses = $conn->query("SHOW TABLES LIKE 'businesses'");
    if ($checkBusinesses->rowCount() == 0) {
        $sql = "CREATE TABLE IF NOT EXISTS businesses (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            business_name VARCHAR(255) NOT NULL,
            industry VARCHAR(100) NOT NULL,
            description TEXT NOT NULL,
            country VARCHAR(100) NOT NULL,
            logo_url VARCHAR(255),
            website VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        ) ENGINE=InnoDB";
        $conn->exec($sql);
        echo "<p style='color: green;'>✓ Businesses table created successfully!</p>";
    } else {
        echo "<p style='color: blue;'>✓ Businesses table already exists!</p>";
    }

    echo "<hr>";
    echo "<h2 style='color: green;'>Database setup completed successfully!</h2>";
    echo "<p><a href='jobs.php'>Go to Jobs Page</a></p>";
    echo "<p><a href='post_job.php'>Post a Job</a></p>";

} catch (PDOException $e) {
    echo "<h2 style='color: red;'>Error: " . $e->getMessage() . "</h2>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Database Setup</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f5f7fb;
        }
        a {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #3a86ff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        a:hover {
            background-color: #1b63e8;
        }
    </style>
</head>
<body>
</body>
</html>
