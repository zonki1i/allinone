<?php
session_start();
require 'config.php';

$success = isset($_GET['sent']) && $_GET['sent'] == '1';
$error = isset($_GET['error']) && $_GET['error'] == '1';

// Fetch reviews from database
try {
    $stmt = $conn->prepare("SELECT * FROM reviews ORDER BY created_at DESC");
    $stmt->execute();
    $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $reviews = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reviews - ALLINONE</title>
    <!-- Google Font: Oswald (Variable) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Oswald", sans-serif;
            font-optical-sizing: auto;
            font-style: normal;
        }

        :root {
            --primary-color: #3a86ff;
            --secondary-color: #3a86ff;
            --accent-color: #3a86ff;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --gray-color: #6c757d;
            --success-color: #38b000;
        }

        body {
            line-height: 1.6;
            color: var(--dark-color);
            background-color: #f5f7fb;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header */
        header {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-color);
            text-decoration: none;
        }

        .logo span {
            color: var(--secondary-color);
        }

        .logo i {
            font-size: 2rem;
        }

        nav ul {
            display: flex;
            list-style: none;
            gap: 30px;
        }

        nav a {
            text-decoration: none;
            color: var(--dark-color);
            font-weight: 600;
            transition: color 0.3s;
        }

        nav a:hover {
            color: var(--primary-color);
        }

        .cta-button {
            background: linear-gradient(135deg, #3a86ff 0%, #1b63e8 100%);
            color: white;
            padding: 14px 35px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 800;
            font-size: 1rem;
            font-family: "Oswald", sans-serif;
            letter-spacing: 1px;
            transition: all 0.4s cubic-bezier(0.23, 1, 0.320, 1);
            box-shadow: 0 8px 25px rgba(58, 134, 255, 0.4);
            border: none;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
            display: inline-block;
        }

        .cta-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s ease;
            z-index: 1;
        }

        .cta-button::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.1) 0%, transparent 100%);
            pointer-events: none;
        }

        .cta-button:hover {
            transform: translateY(-3px) scale(1.08);
            box-shadow: 0 12px 35px rgba(58, 134, 255, 0.5);
            background: linear-gradient(135deg, #1b63e8 0%, #0d47a1 100%);
        }

        .cta-button:hover::before {
            left: 100%;
        }

        .cta-button:active {
            transform: translateY(-1px);
            box-shadow: 0 5px 15px rgba(58, 134, 255, 0.4);
        }

        /* Hero Section */
        .hero {
            padding: 80px 0;
            background: linear-gradient(135deg, #f5f7fb 0%, #e3edff 100%);
            text-align: center;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            color: var(--dark-color);
        }

        .hero p {
            font-size: 1.2rem;
            color: var(--gray-color);
            max-width: 700px;
            margin: 0 auto 40px;
        }

        /* Reviews Section */
        .reviews-section {
            padding: 60px 0;
            background-color: white;
        }

        .reviews-section h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 40px;
            color: var(--dark-color);
        }

        .reviews-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-bottom: 60px;
        }

        .review-card {
            background-color: var(--light-color);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .review-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .review-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            margin-right: 15px;
        }

        .review-info h4 {
            margin-bottom: 5px;
            color: var(--dark-color);
        }

        .review-stars {
            color: #ffd700;
            margin-bottom: 15px;
        }

        .review-text {
            color: var(--gray-color);
            line-height: 1.6;
        }

        /* Submit Review Section */
        .submit-review {
            max-width: 800px;
            margin: 0 auto;
            background-color: var(--light-color);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .submit-review h3 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--dark-color);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: var(--dark-color);
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .form-group textarea {
            height: 120px;
            resize: vertical;
        }

        .submit-btn {
            background-color: var(--primary-color);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 30px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }

        .submit-btn:hover {
            background-color: var(--secondary-color);
        }

        .login-message {
            text-align: center;
            padding: 40px;
            background: linear-gradient(135deg, #e3f2fd 0%, #f3e5f5 100%);
            border: 2px solid var(--primary-color);
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 8px 25px rgba(58, 134, 255, 0.15);
        }

        .login-message p {
            margin-bottom: 25px;
            color: var(--dark-color);
            font-weight: 700;
            font-size: 1.2rem;
            font-family: "Oswald", sans-serif;
            letter-spacing: 0.5px;
        }

        .login-btn {
            display: inline-block;
            background: linear-gradient(135deg, #3a86ff 0%, #1b63e8 100%);
            color: white;
            padding: 16px 45px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 800;
            font-size: 1.15rem;
            font-family: "Oswald", sans-serif;
            letter-spacing: 1px;
            transition: all 0.4s cubic-bezier(0.23, 1, 0.320, 1);
            box-shadow: 0 8px 25px rgba(58, 134, 255, 0.4);
            border: none;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
        }

        .login-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s ease;
            z-index: 1;
        }

        .login-btn::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.1) 0%, transparent 100%);
            pointer-events: none;
        }

        .login-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 35px rgba(58, 134, 255, 0.5);
            background: linear-gradient(135deg, #1b63e8 0%, #0d47a1 100%);
        }

        .login-btn:hover::before {
            left: 100%;
        }

        .login-btn:active {
            transform: translateY(-1px);
            box-shadow: 0 5px 15px rgba(58, 134, 255, 0.4);
        }

        /* Footer */
        footer {
            background-color: var(--dark-color);
            color: white;
            padding: 40px 0;
            text-align: center;
        }

        @media (max-width: 768px) {
            .hero h1 {
                font-size: 2rem;
            }

            .reviews-section h2 {
                font-size: 2rem;
            }

            .submit-review {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <a href="index.php" class="logo">
                    <i class="fas fa-briefcase"></i>
                    ALL<span>IN</span>ONE
                </a>

                <nav>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="freelancing.php">Freelancers</a></li>
                        <li><a href="jobs.php">Jobs</a></li>
                        <li><a href="hire.php">Hire</a></li>
                        <li><a href="reviews.php">Reviews</a></li>
                    </ul>
                </nav>

                <a href="signUp.php" class="cta-button">Get Started</a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>User Reviews</h1>
            <p>See what our community has to say about their experiences on our platform. Real feedback from real users.</p>
        </div>
    </section>

    <!-- Reviews Section -->
    <section class="reviews-section">
        <div class="container">
            <div class="submit-review">
                <h3>Share Your Experience</h3>
                <div class="login-message">
                    <p>You must be logged in to submit a review.</p>
                    <a href="login.php" class="login-btn">Login First</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer id="legal">
        <div class="container footer-content-wrapper">
            <div class="footer-columns">
                <!-- About Us -->
                <div class="footer-column">
                    <h3>About Us</h3>
                    <ul>
                        <li><a href="#">Our Mission</a></li>
                        <li><a href="#">Team</a></li>
                        <li><a href="#">Careers</a></li>
                        <li><a href="#">Press</a></li>
                    </ul>
                </div>

                <!-- For Freelancers -->
                <div class="footer-column">
                    <h3>For Freelancers</h3>
                    <ul>
                        <li><a href="#">Find Projects</a></li>
                        <li><a href="#">Build Portfolio</a></li>
                        <li><a href="#">Freelancer Resources</a></li>
                        <li><a href="#">Community</a></li>
                    </ul>
                </div>

                <!-- For Businesses -->
                <div class="footer-column">
                    <h3>For Businesses</h3>
                    <ul>
                        <li><a href="#">Hire Talent</a></li>
                        <li><a href="#">Post Projects</a></li>
                        <li><a href="#">B2B Services</a></li>
                        <li><a href="#">Enterprise Solutions</a></li>
                    </ul>
                </div>

                <!-- Legal -->
                <div class="footer-column">
                    <h3>Legal</h3>
                    <ul>
                        <li><a href="#">Terms of Service</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Cookie Policy</a></li>
                        <li><a href="#">GDPR</a></li>
                    </ul>
                    <div class="notice">
                        <p>allinone.com is a platform connecting freelancers, job seekers, and businesses. We do not charge any commission fees.</p>
                    </div>
                </div>
            </div>

            <div class="copyright">
                &copy; 2025 allinone.com. All rights reserved.
            </div>
        </div>
    </footer>

    <style>
        /* Footer Styles */
        footer {
            position: relative;
            color: white;
            background-color: blue;
            overflow: hidden;
        }

        .footer-wave {
            position: absolute;
            top: -150px;
            left: 0;
            width: 100%;
            height: 150px;
            z-index: 1;
        }

        .footer-wave svg {
            width: 100%;
            height: 100%;
        }

        .footer-content-wrapper {
            position: relative;
            z-index: 2;
            padding: 60px 0 40px;
        }

        .footer-columns {
            display: flex;
            flex-wrap: wrap;
            gap: 50px;
            margin-bottom: 40px;
        }

        .footer-column {
            flex: 1;
            min-width: 200px;
        }

        .footer-column h3 {
            font-size: 1.3rem;
            margin-bottom: 20px;
            color: white;
        }

        .footer-column ul {
            list-style: none;
        }

        .footer-column ul li {
            margin-bottom: 10px;
        }

        .footer-column a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-column a:hover {
            color: white;
        }

        .notice {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.8);
        }

        .copyright {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.9rem;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .footer-columns {
                gap: 30px;
            }
        }

        @media (max-width: 768px) {
            .footer-columns {
                flex-direction: column;
                gap: 40px;
            }
            .footer-column {
                min-width: 100%;
            }
        }
    </style>
</body>
</html>
