<?php
session_start();
require 'config.php';

// Fetch all businesses
$stmt = $conn->prepare("SELECT * FROM businesses ORDER BY created_at DESC");
$stmt->execute();
$businesses = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Businesses - ALLINONE</title>
    <!-- Google Font: Oswald (Variable) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Oswald", sans-serif;
            font-optical-sizing: auto;
            font-style: normal;
            background-color: #f5f7fb;
            color: #212529;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header */
        header {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.8rem;
            font-weight: 700;
            color: #3a86ff;
            text-decoration: none;
        }

        .logo span {
            color: #8338ec;
        }

        nav ul {
            display: flex;
            list-style: none;
            gap: 30px;
        }

        nav a {
            text-decoration: none;
            color: #212529;
            font-weight: 600;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #3a86ff;
        }

        .cta-button {
            background: linear-gradient(135deg, #3a86ff 0%, #1b63e8 100%);
            color: white;
            padding: 14px 35px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 800;
            font-size: 1rem;
            font-family: "Oswald", sans-serif;
            letter-spacing: 1px;
            transition: all 0.4s cubic-bezier(0.23, 1, 0.320, 1);
            box-shadow: 0 8px 25px rgba(58, 134, 255, 0.4);
            border: none;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
            display: inline-block;
        }

        .cta-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s ease;
            z-index: 1;
        }

        .cta-button:hover {
            transform: translateY(-3px) scale(1.08);
            box-shadow: 0 12px 35px rgba(58, 134, 255, 0.5);
            background: linear-gradient(135deg, #1b63e8 0%, #0d47a1 100%);
        }

        .cta-button:hover::before {
            left: 100%;
        }

        /* Hero Section */
        .hero {
            padding: 80px 0;
            background: linear-gradient(135deg, #f5f7fb 0%, #e3edff 100%);
            text-align: center;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            color: #212529;
        }

        .hero p {
            font-size: 1.2rem;
            color: #6c757d;
            max-width: 700px;
            margin: 0 auto 40px;
        }

        /* Businesses Section */
        .businesses-section {
            padding: 60px 0;
        }

        .businesses-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
            margin-bottom: 60px;
        }

        .business-card {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .business-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .business-logo {
            width: 80px;
            height: 80px;
            margin: 0 auto 20px;
            background-color: #f5f7fb;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .business-logo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        .business-card h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: #3a86ff;
            text-align: center;
        }

        .business-industry {
            text-align: center;
            color: #8338ec;
            font-weight: 600;
            margin-bottom: 15px;
            font-size: 0.95rem;
        }

        .business-country {
            text-align: center;
            color: #6c757d;
            margin-bottom: 15px;
            font-size: 0.9rem;
        }

        .business-description {
            color: #6c757d;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .business-website {
            text-align: center;
        }

        .business-website a {
            color: #3a86ff;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        .business-website a:hover {
            color: #8338ec;
            text-decoration: underline;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }

        .empty-state i {
            font-size: 4rem;
            color: #ddd;
            margin-bottom: 20px;
        }

        .empty-state p {
            color: #6c757d;
            font-size: 1.1rem;
            margin-bottom: 30px;
        }

        /* Footer */
        footer {
            background-color: #212529;
            color: white;
            padding: 40px 0;
            text-align: center;
            margin-top: 60px;
        }

        @media (max-width: 768px) {
            .hero h1 {
                font-size: 2rem;
            }

            nav ul {
                gap: 15px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <a href="index.php" class="logo">
                    <i class="fas fa-briefcase"></i>
                    ALL<span>IN</span>ONE
                </a>

                <nav>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="freelancing.php">Freelancers</a></li>
                        <li><a href="jobs.php">Jobs</a></li>
                        <li><a href="businesses.php">Businesses</a></li>
                        <li><a href="reviews.php">Reviews</a></li>
                    </ul>
                </nav>

                <a href="signUp.php" class="cta-button">Get Started</a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Our Businesses</h1>
            <p>Discover amazing businesses and B2B services in our community marketplace.</p>
        </div>
    </section>

    <!-- Businesses Section -->
    <section class="businesses-section">
        <div class="container">
            <?php if (count($businesses) > 0): ?>
                <div class="businesses-grid">
                    <?php foreach ($businesses as $business): ?>
                        <div class="business-card">
                            <?php if ($business['logo_url']): ?>
                                <div class="business-logo">
                                    <img src="<?php echo htmlspecialchars($business['logo_url']); ?>" alt="<?php echo htmlspecialchars($business['business_name']); ?>">
                                </div>
                            <?php endif; ?>
                            
                            <h3><?php echo htmlspecialchars($business['business_name']); ?></h3>
                            <p class="business-industry"><i class="fas fa-industry"></i> <?php echo htmlspecialchars($business['industry']); ?></p>
                            <p class="business-country"><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($business['country']); ?></p>
                            
                            <p class="business-description"><?php echo nl2br(htmlspecialchars($business['description'])); ?></p>
                            
                            <?php if ($business['website']): ?>
                                <div class="business-website">
                                    <a href="<?php echo htmlspecialchars($business['website']); ?>" target="_blank">Visit Website <i class="fas fa-external-link-alt"></i></a>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-store"></i>
                    <p>No businesses posted yet. Be the first to post your business!</p>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <a href="post_business.php" class="cta-button">Post Your Business</a>
                    <?php else: ?>
                        <a href="login.php" class="cta-button">Login to Post</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <p>&copy; 2025 ALLINONE. All rights reserved. | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
        </div>
    </footer>
</body>
</html>
