<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Fetch current user data
$stmt = $conn->prepare("SELECT username, email, role FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header("Location: login.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_username') {
        $new_username = trim($_POST['new_username'] ?? '');
        
        if (empty($new_username)) {
            $error = "Username cannot be empty.";
        } else {
            try {
                $stmt = $conn->prepare("UPDATE users SET username = ? WHERE id = ?");
                $stmt->execute([$new_username, $user_id]);
                $message = "Username updated successfully!";
                $user['username'] = $new_username;
            } catch (PDOException $e) {
                $error = "Username already exists.";
            }
        }
    }
    
    elseif ($action === 'update_email') {
        $new_email = trim($_POST['new_email'] ?? '');
        
        if (empty($new_email) || !filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
            $error = "Please enter a valid email.";
        } else {
            try {
                $stmt = $conn->prepare("UPDATE users SET email = ? WHERE id = ?");
                $stmt->execute([$new_email, $user_id]);
                $message = "Email updated successfully!";
                $user['email'] = $new_email;
            } catch (PDOException $e) {
                $error = "Email already exists.";
            }
        }
    }
    
    elseif ($action === 'update_password') {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error = "All password fields are required.";
        } elseif ($new_password !== $confirm_password) {
            $error = "New passwords do not match.";
        } else {
            // Verify current password
            $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!password_verify($current_password, $result['password'])) {
                $error = "Current password is incorrect.";
            } else {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->execute([$hashed_password, $user_id]);
                $message = "Password updated successfully!";
            }
        }
    }
    
    elseif ($action === 'update_role') {
        $new_role = trim($_POST['new_role'] ?? '');
        $valid_roles = ['freelancer', 'job_seeker', 'business'];
        
        if (!in_array($new_role, $valid_roles)) {
            $error = "Invalid role selected.";
        } else {
            // If changing FROM freelancer, delete freelancer profile
            if ($user['role'] === 'freelancer' && $new_role !== 'freelancer') {
                try {
                    $stmt = $conn->prepare("DELETE FROM freelancers WHERE user_id = ?");
                    $stmt->execute([$user_id]);
                } catch (PDOException $e) {
                    // If user_id doesn't exist in freelancers, that's fine
                }
            }
            
            // Update role
            $stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
            $stmt->execute([$new_role, $user_id]);
            $message = "Role updated successfully!";
            $user['role'] = $new_role;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Settings - ALLINONE</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: "Oswald", sans-serif;
            background: linear-gradient(135deg, #3a86ff 0%, #8338ec 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
        }

        .header {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
        }

        .back-btn {
            align-items: center;
            background-image: linear-gradient(144deg, #af40ff, #5b42f3 50%, #00ddeb);
            border: 0;
            border-radius: 8px;
            box-shadow: rgba(151, 65, 252, 0.2) 0 15px 30px -5px;
            box-sizing: border-box;
            color: #000000;
            display: flex;
            font-size: 18px;
            justify-content: center;
            line-height: 1em;
            max-width: 100%;
            min-width: 140px;
            padding: 3px;
            text-decoration: none;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
            white-space: nowrap;
            cursor: pointer;
            transition: all 0.3s;
            margin-right: 15px;
        }

        .back-btn:active,
        .back-btn:hover {
            outline: 0;
        }

        .back-btn span {
            background-color: rgb(252, 252, 252);
            padding: 12px 20px;
            border-radius: 6px;
            width: 100%;
            height: 100%;
            transition: 300ms;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            color: #000000;
        }

        .back-btn:hover span {
            background: none;
        }

        .back-btn:active {
            transform: scale(0.9);
        }

        h1 {
            color: white;
            font-size: 2rem;
        }

        .settings-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }

        .setting-section {
            margin-bottom: 25px;
            padding-bottom: 25px;
            border-bottom: 1px solid #eee;
        }

        .setting-section:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }

        .setting-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
            display: block;
        }

        .current-value {
            background: #f5f7fb;
            padding: 10px 12px;
            border-radius: 8px;
            color: #666;
            font-size: 0.95rem;
            margin-bottom: 12px;
        }

        .form-group {
            margin-bottom: 12px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 0.95rem;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus,
        select:focus {
            outline: none;
            border-color: #3a86ff;
            box-shadow: 0 0 0 3px rgba(58, 134, 255, 0.1);
        }

        .button-group {
            display: flex;
            gap: 10px;
        }

        button {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 0.95rem;
        }

        .btn-submit {
            background: linear-gradient(135deg, #3a86ff, #8338ec);
            color: white;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(58, 134, 255, 0.3);
        }

        .btn-cancel {
            background: #f5f7fb;
            color: #666;
        }

        .btn-cancel:hover {
            background: #eee;
        }

        .message {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .hidden {
            display: none;
        }

        .toggle-form {
            background: #f5f7fb;
            color: #3a86ff;
            padding: 10px 15px;
            border: 1px solid #ddd;
            cursor: pointer;
            font-size: 0.9rem;
            margin-top: 10px;
        }

        .toggle-form:hover {
            background: #e8f0ff;
        }

        .form-content {
            margin-top: 12px;
            padding-top: 12px;
            border-top: 1px solid #eee;
        }

        @media (max-width: 768px) {
            body {
                padding: 20px 15px;
            }

            .container {
                max-width: 100%;
            }

            .header {
                margin-bottom: 20px;
            }

            .back-btn {
                width: 36px;
                height: 36px;
                font-size: 1rem;
                margin-right: 12px;
            }

            h1 {
                font-size: 1.5rem;
            }

            .settings-card {
                padding: 20px 15px;
                border-radius: 12px;
            }

            .button-group {
                flex-direction: column;
            }

            button {
                width: 100%;
            }

            .toggle-form {
                width: 100%;
                text-align: center;
            }
        }

        @media (max-width: 480px) {
            .header {
                flex-direction: row;
            }

            h1 {
                font-size: 1.2rem;
                margin: 0;
            }

            .back-btn {
                width: 32px;
                height: 32px;
                font-size: 0.9rem;
                margin-right: 10px;
                flex-shrink: 0;
            }

            .settings-card {
                padding: 15px 12px;
            }

            .setting-label {
                font-size: 0.9rem;
            }

            input[type="text"],
            input[type="email"],
            input[type="password"],
            select {
                padding: 10px;
                font-size: 0.9rem;
            }

            button {
                padding: 10px;
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <button class="back-btn" onclick="goBack()">
                <span><i class="fas fa-arrow-left"></i> Back</span>
            </button>
            <h1>Account Settings</h1>
        </div>

        <?php if (!empty($message)): ?>
            <div class="message success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="settings-card">
            <!-- Username Setting -->
            <div class="setting-section">
                <label class="setting-label">Username</label>
                <div class="current-value"><?php echo htmlspecialchars($user['username']); ?></div>
                <button class="toggle-form" onclick="toggleForm('usernameForm')">Change Username</button>
                
                <div class="form-content hidden" id="usernameForm">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="update_username">
                        <div class="form-group">
                            <input type="text" name="new_username" placeholder="New username" required>
                        </div>
                        <div class="button-group">
                            <button type="submit" class="btn-submit">Update</button>
                            <button type="button" class="btn-cancel" onclick="toggleForm('usernameForm')">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Email Setting -->
            <div class="setting-section">
                <label class="setting-label">Email</label>
                <div class="current-value"><?php echo htmlspecialchars($user['email']); ?></div>
                <button class="toggle-form" onclick="toggleForm('emailForm')">Change Email</button>
                
                <div class="form-content hidden" id="emailForm">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="update_email">
                        <div class="form-group">
                            <input type="email" name="new_email" placeholder="New email" required>
                        </div>
                        <div class="button-group">
                            <button type="submit" class="btn-submit">Update</button>
                            <button type="button" class="btn-cancel" onclick="toggleForm('emailForm')">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Password Setting -->
            <div class="setting-section">
                <label class="setting-label">Password</label>
                <div class="current-value">••••••••</div>
                <button class="toggle-form" onclick="toggleForm('passwordForm')">Change Password</button>
                
                <div class="form-content hidden" id="passwordForm">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="update_password">
                        <div class="form-group">
                            <input type="password" name="current_password" placeholder="Current password" required>
                        </div>
                        <div class="form-group">
                            <input type="password" name="new_password" placeholder="New password" required>
                        </div>
                        <div class="form-group">
                            <input type="password" name="confirm_password" placeholder="Confirm new password" required>
                        </div>
                        <div class="button-group">
                            <button type="submit" class="btn-submit">Update</button>
                            <button type="button" class="btn-cancel" onclick="toggleForm('passwordForm')">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Role Setting -->
            <div class="setting-section">
                <label class="setting-label">User Role</label>
                <div class="current-value">
                    <?php 
                        $roles = [
                            'freelancer' => 'Freelancer',
                            'job_seeker' => 'Job Seeker',
                            'business' => 'Business'
                        ];
                        echo $roles[$user['role']] ?? ucfirst($user['role']);
                    ?>
                </div>
                <button class="toggle-form" onclick="toggleForm('roleForm')">Change Role</button>
                
                <div class="form-content hidden" id="roleForm">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="update_role">
                        <div class="form-group">
                            <select name="new_role" required>
                                <option value="">-- Select a role --</option>
                                <option value="freelancer" <?php echo ($user['role'] === 'freelancer') ? 'selected' : ''; ?>>Freelancer</option>
                                <option value="job_seeker" <?php echo ($user['role'] === 'job_seeker') ? 'selected' : ''; ?>>Job Seeker</option>
                                <option value="business" <?php echo ($user['role'] === 'business') ? 'selected' : ''; ?>>Business</option>
                            </select>
                        </div>
                        <?php if ($user['role'] === 'freelancer'): ?>
                            <p style="font-size: 0.85rem; color: #e63946; margin-bottom: 12px;">
                                <i class="fas fa-exclamation-circle"></i> 
                                Changing your role will delete your freelancer profile.
                            </p>
                        <?php endif; ?>
                        <div class="button-group">
                            <button type="submit" class="btn-submit">Update</button>
                            <button type="button" class="btn-cancel" onclick="toggleForm('roleForm')">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleForm(formId) {
            const form = document.getElementById(formId);
            form.classList.toggle('hidden');
        }

        function goBack() {
            // Try to go back to the previous page if it was from within the app
            const referer = document.referrer;
            if (referer && referer.includes(window.location.hostname)) {
                window.history.back();
            } else {
                // Default to indexLog.php if no valid referrer
                window.location.href = 'indexlog.php';
            }
        }
    </script>
</body>
</html>
