<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'set') {
        $role = $_POST['role'] ?? null;
        if ($role) {
            $_SESSION['role_override'] = $role;
        } else {
            unset($_SESSION['role_override']);
        }
    }
    if (($action === 'open') || ($action === 'set')) {
        header('Location: jobs.php');
        exit();
    }
}

$current = $_SESSION['role_override'] ?? 'none (use DB or set override)';
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Preview Test - Jobs Role Toggle</title>
    <style>
        body { font-family: Arial, Helvetica, sans-serif; background:#f5f7fb; padding:40px; }
        .card { background: #fff; padding:20px; border-radius:10px; box-shadow:0 8px 30px rgba(0,0,0,0.06); max-width:720px; margin:0 auto; }
        .roles { display:flex; gap:10px; flex-wrap:wrap; margin-top:12px; }
        button { padding:10px 14px; border-radius:8px; border:none; cursor:pointer; font-weight:700; }
        .btn-job { background: linear-gradient(135deg,#3a86ff,#1b63e8); color:#fff; }
        .btn-freelancer { background: linear-gradient(135deg,#8338ec,#6a2fc9); color:#fff; }
        .btn-business { background: linear-gradient(135deg,#00c6ff,#0072ff); color:#fff; }
        .btn-none { background:#6c757d; color:#fff; }
        .open { margin-top:18px; display:inline-block; }
        .note { margin-top:12px; color:#666; font-size:0.95rem; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Preview Test — Role Toggle</h2>
        <p class="note">Current session override: <strong><?php echo htmlspecialchars($current); ?></strong></p>

        <form method="post">
            <input type="hidden" name="action" value="set">
            <div class="roles">
                <button type="submit" name="role" value="job_seeker" class="btn-job">Set Job Seeker</button>
                <button type="submit" name="role" value="freelancer" class="btn-freelancer">Set Freelancer</button>
                <button type="submit" name="role" value="business" class="btn-business">Set Business</button>
                <button type="submit" name="role" value="" class="btn-none">Clear Override (Logged out / DB)</button>
            </div>
        </form>

        <div style="margin-top:10px;">
            <button type="button" class="open btn-job" onclick="window.open('jobs.php', '_blank')">Open Jobs Page Now (New Tab)</button>
        </div>

        <p class="note">Tip: use the browser back button to return here — session override persists until cleared.</p>
    </div>
</body>
</html>
