<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hire Freelancers - ALLINONE</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary-color: #3a86ff;
            --secondary-color: #8338ec;
            --accent-color: #ff006e;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --gray-color: #6c757d;
            --success-color: #38b000;
        }

        body {
            line-height: 1.6;
            color: var(--dark-color);
            background-color: #f5f7fb;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header */
        header {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-color);
            text-decoration: none;
        }

        .logo span {
            color: var(--secondary-color);
        }

        .logo i {
            font-size: 2rem;
        }

        nav ul {
            display: flex;
            list-style: none;
            gap: 30px;
        }

        nav a {
            text-decoration: none;
            color: var(--dark-color);
            font-weight: 600;
            transition: color 0.3s;
        }

        nav a:hover {
            color: var(--primary-color);
        }

        .cta-button {
            background-color: var(--primary-color);
            color: white;
            padding: 10px 25px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            transition: background-color 0.3s;
        }

        .cta-button:hover {
            background-color: var(--secondary-color);
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--dark-color);
            cursor: pointer;
        }

        .profile-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            position: relative;
            transition: background-color 0.3s;
        }

        .profile-icon:hover {
            background-color: var(--secondary-color);
        }

        .profile-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            min-width: 180px;
            display: none;
            z-index: 1000;
        }

        .profile-dropdown.active {
            display: block;
        }

        .profile-dropdown a {
            display: block;
            padding: 12px 16px;
            color: var(--dark-color);
            text-decoration: none;
            font-weight: 500;
            border-bottom: 1px solid #eee;
            transition: background-color 0.3s;
        }

        .profile-dropdown a:last-child {
            border-bottom: none;
        }

        .profile-dropdown a:hover {
            background-color: #f5f7fb;
            color: var(--primary-color);
        }

        .profile-icon::before {
            content: "";
            display: none;
        }

        .profile-icon:hover::before {
            display: none;
        }

        /* Hero Section */
        .hero {
            padding: 80px 0;
            background: linear-gradient(135deg, #f5f7fb 0%, #e3edff 100%);
            text-align: center;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            color: var(--dark-color);
        }

        .hero p {
            font-size: 1.2rem;
            color: var(--gray-color);
            max-width: 700px;
            margin: 0 auto 40px;
        }

        /* Post Job Section */
        .post-job {
            padding: 60px 0;
            background-color: white;
        }

        .post-job h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 40px;
            color: var(--dark-color);
        }

        .job-form {
            max-width: 800px;
            margin: 0 auto;
            background-color: var(--light-color);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: var(--dark-color);
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .form-group textarea {
            height: 120px;
            resize: vertical;
        }

        .submit-btn {
            background-color: var(--primary-color);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 30px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }

        .submit-btn:hover {
            background-color: var(--secondary-color);
        }

        /* Footer */
        footer {
            background-color: var(--dark-color);
            color: white;
            padding: 40px 0;
            text-align: center;
        }

        @media (max-width: 768px) {
            .header-content {
                flex-wrap: wrap;
            }

            nav {
                display: none;
                width: 100%;
                order: 3;
                margin-top: 20px;
            }

            nav.active {
                display: block;
            }

            nav ul {
                flex-direction: column;
                gap: 15px;
            }

            .mobile-menu-btn {
                display: block;
            }

            .hero h1 {
                font-size: 2rem;
            }

            .post-job h2 {
                font-size: 2rem;
            }

            .job-form {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <a href="indexLog.php" class="logo">
                    <i class="fas fa-briefcase"></i>
                    ALL<span>IN</span>ONE
                </a>

                <button class="mobile-menu-btn" id="mobileMenuBtn">
                    <i class="fas fa-bars"></i>
                </button>

                <nav id="mainNav">
                    <ul>
                       <li><a href="indexLog.php">Home</a></li>
                        <li><a href="freelancinglog.php">Freelancers</a></li>
                        <li><a href="jobs.php">Jobs</a></li>
                        <li><a href="hirelog.php">Hire</a></li>
                        <li><a href="reviewslog.php">Reviews</a></li>
                    </ul>
                </nav>

                <div class="profile-icon" id="profileIcon">
                    <i class="fas fa-user"></i>
                    <div class="profile-dropdown" id="profileDropdown">
                        <a href="accSettings.php">Account Settings</a>
                        <a href="logout.php">Log out</a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Hire A Top Talent</h1>
            <p>Post your project and connect with skilled freelancers ready to bring your ideas to life. Find the perfect match for your business needs.</p>
        </div>
    </section>

    <!-- Post Job Section -->
    <section class="post-job">
        <div class="container">
            <h2>Post Your Job</h2>
            <form class="job-form" action="post_job.php" method="POST">
                <div class="form-group">
                    <label for="job-title">Job Title</label>
                    <input type="text" id="job-title" name="job_title" placeholder="e.g., Web Developer Needed" required>
                </div>

                <div class="form-group">
                    <label for="category">Category</label>
                    <select id="category" name="category" required>
                        <option value="">Select Category</option>
                        <option value="web-development">Web Development</option>
                        <option value="design">Design</option>
                        <option value="writing">Writing</option>
                        <option value="marketing">Marketing</option>
                        <option value="other">Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="budget">Budget (USD)</label>
                    <input type="number" id="budget" name="budget" placeholder="500" min="1" required>
                </div>

                <div class="form-group">
                    <label for="description">Job Description</label>
                    <textarea id="description" name="description" placeholder="Describe your project requirements..." required></textarea>
                </div>

                <div class="form-group">
                    <label for="skills">Required Skills</label>
                    <input type="text" id="skills" name="skills" placeholder="e.g., PHP, JavaScript, HTML" required>
                </div>

                <button type="submit" class="submit-btn">Post Job</button>
            </form>
        </div>
    </section>

    <!-- Footer -->
    <footer id="legal">
        <div class="container footer-content-wrapper">
            <div class="footer-columns">
                <!-- About Us -->
                <div class="footer-column">
                    <h3>About Us</h3>
                    <ul>
                        <li><a href="#">Our Mission</a></li>
                        <li><a href="#">Team</a></li>
                        <li><a href="#">Careers</a></li>
                        <li><a href="#">Press</a></li>
                    </ul>
                </div>

                <!-- For Freelancers -->
                <div class="footer-column">
                    <h3>For Freelancers</h3>
                    <ul>
                        <li><a href="#">Find Projects</a></li>
                        <li><a href="#">Build Portfolio</a></li>
                        <li><a href="#">Freelancer Resources</a></li>
                        <li><a href="#">Community</a></li>
                    </ul>
                </div>

                <!-- For Businesses -->
                <div class="footer-column">
                    <h3>For Businesses</h3>
                    <ul>
                        <li><a href="#">Hire Talent</a></li>
                        <li><a href="#">Post Projects</a></li>
                        <li><a href="#">B2B Services</a></li>
                        <li><a href="#">Enterprise Solutions</a></li>
                    </ul>
                </div>

                <!-- Legal -->
                <div class="footer-column">
                    <h3>Legal</h3>
                    <ul>
                        <li><a href="#">Terms of Service</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Cookie Policy</a></li>
                        <li><a href="#">GDPR</a></li>
                    </ul>
                    <div class="notice">
                        <p>allinone.com is a platform connecting freelancers, job seekers, and businesses. We do not charge any commission fees.</p>
                    </div>
                </div>
            </div>

            <div class="copyright">
                &copy; 2025 allinone.com. All rights reserved.
            </div>
        </div>
    </footer>

    <script>
    // Mobile menu toggle
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mainNav = document.getElementById('mainNav');

    mobileMenuBtn.addEventListener('click', () => {
        mainNav.classList.toggle('active');
        const icon = mobileMenuBtn.querySelector('i');
        icon.classList.toggle('fa-bars');
        icon.classList.toggle('fa-times');
    });

    // Smooth scrolling ONLY for real hash links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');

            if (targetId === '#') return; // allow normal click

            e.preventDefault();
            const target = document.querySelector(targetId);
            if (!target) return;

            window.scrollTo({
                top: target.offsetTop - 80,
                behavior: 'smooth'
            });
        });
    });
</script>

    <style>
        /* Footer Styles */
        footer {
            position: relative;
            color: white;
            background-color: blue;
            overflow: hidden;
        }

        .footer-wave {
            position: absolute;
            top: -150px;
            left: 0;
            width: 100%;
            height: 150px;
            z-index: 1;
        }

        .footer-wave svg {
            width: 100%;
            height: 100%;
        }

        .footer-content-wrapper {
            position: relative;
            z-index: 2;
            padding: 60px 0 40px;
        }

        .footer-columns {
            display: flex;
            flex-wrap: wrap;
            gap: 50px;
            margin-bottom: 40px;
        }

        .footer-column {
            flex: 1;
            min-width: 200px;
        }

        .footer-column h3 {
            font-size: 1.3rem;
            margin-bottom: 20px;
            color: white;
        }

        .footer-column ul {
            list-style: none;
        }

        .footer-column ul li {
            margin-bottom: 10px;
        }

        .footer-column a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-column a:hover {
            color: white;
        }

        .notice {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.8);
        }

        .copyright {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.9rem;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .footer-columns {
                gap: 30px;
            }
        }

        @media (max-width: 768px) {
            .footer-columns {
                flex-direction: column;
                gap: 40px;
            }
            .footer-column {
                min-width: 100%;
            }
        }
    </style>

    <script>
        // Profile dropdown toggle
        const profileIcon = document.getElementById('profileIcon');
        const profileDropdown = document.getElementById('profileDropdown');

        if (profileIcon) {
            profileIcon.addEventListener('click', (e) => {
                e.stopPropagation();
                profileDropdown.classList.toggle('active');
            });
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', () => {
            if (profileDropdown) {
                profileDropdown.classList.remove('active');
            }
        });
    </script>
</body>
</html>
