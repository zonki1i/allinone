<?php
require_once 'config.php';

try {
    $sql = "ALTER TABLE reviews DISCARD TABLESPACE";
    $conn->exec($sql);
    echo "Tablespace discarded successfully!\n";
} catch (PDOException $e) {
    echo "Error discarding tablespace: " . $e->getMessage() . "\n";
}
?>
