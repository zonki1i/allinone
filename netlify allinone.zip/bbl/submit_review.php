<?php
session_start();
require 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'] ?? '';
    $role = $_POST['role'] ?? '';
    $rating = $_POST['rating'] ?? '';
    $review = $_POST['review'] ?? '';

    if (!empty($name) && !empty($role) && !empty($rating) && !empty($review)) {
        try {
            $stmt = $conn->prepare(
                "INSERT INTO reviews (name, role, rating, review, created_at)
                 VALUES (:name, :role, :rating, :review, NOW())"
            );

            $stmt->execute([
                ':name' => $name,
                ':role' => $role,
                ':rating' => $rating,
                ':review' => $review
            ]);

            header("Location: reviewslog.php?sent=1");
            exit;

        } catch (Exception $e) {
            header("Location: reviewslog.php?error=1");
            exit;
        }
    } else {
        header("Location: reviewslog.php?error=1");
        exit;
    }
} else {
    header("Location: reviewslog.php");
    exit;
}
