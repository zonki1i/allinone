<?php
require_once 'config.php';

try {
    $stmt = $conn->prepare("SHOW TABLES LIKE 'reviews'");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        echo "Table 'reviews' exists.\n";
    } else {
        echo "Table 'reviews' does not exist.\n";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
