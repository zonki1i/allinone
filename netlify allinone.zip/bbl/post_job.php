<?php
session_start();
require 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $job_title = trim($_POST['job_title'] ?? '');
    $company_name = trim($_POST['company_name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $salary_min = trim($_POST['salary_min'] ?? '');
    $salary_max = trim($_POST['salary_max'] ?? '');
    $job_type = trim($_POST['job_type'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $skills_required = trim($_POST['skills_required'] ?? '');

    if ($job_title && $company_name && $description && $job_type && $location) {
        try {
            $stmt = $conn->prepare("INSERT INTO jobs (user_id, job_title, company_name, description, salary_min, salary_max, job_type, location, skills_required) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            if ($stmt->execute([$user_id, $job_title, $company_name, $description, $salary_min ?: null, $salary_max ?: null, $job_type, $location, $skills_required])) {
                $message = "Job posted successfully!";
                // Clear the form
                $_POST = [];
            } else {
                $error = "Failed to post job. Please try again.";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    } else {
        $error = "Please fill in all required fields.";
    }
}

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Optional: only businesses can post jobs
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'business') {
    header("Location: jobs.php");
    exit();
}

require 'config.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post a Job - ALLINONE</title>
    <!-- Google Font: Oswald (Variable) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Oswald", sans-serif;
            font-optical-sizing: auto;
            font-style: normal;
            background-color: #f5f7fb;
            color: #212529;
        }

        .container {
            width: 100%;
            max-width: 900px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .form-container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-bottom: 10px;
            color: #3a86ff;
            font-size: 2rem;
        }

        .subtitle {
            color: #6c757d;
            margin-bottom: 30px;
            font-size: 1.1rem;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        @media (max-width: 600px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 700;
            color: #212529;
        }

        input[type="text"],
        input[type="number"],
        input[type="email"],
        textarea,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            font-family: "Oswald", sans-serif;
        }

        textarea {
            min-height: 150px;
            resize: vertical;
        }

        input:focus,
        textarea:focus,
        select:focus {
            outline: none;
            border-color: #3a86ff;
            box-shadow: 0 0 5px rgba(58, 134, 255, 0.3);
        }

        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 30px;
        }

        button, .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            font-weight: 700;
            cursor: pointer;
            font-family: "Oswald", sans-serif;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3a86ff 0%, #1b63e8 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(58, 134, 255, 0.4);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #3a86ff;
            text-decoration: none;
            font-weight: 600;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        .required {
            color: #dc3545;
        }

        /* Modern Alert Styles */
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideDown 0.4s ease-out;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            border-left: 4px solid #28a745;
            color: #155724;
        }

        .alert-error {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            border-left: 4px solid #dc3545;
            color: #721c24;
        }

        .alert-icon {
            font-size: 1.5rem;
            flex-shrink: 0;
        }

        .alert-success .alert-icon {
            color: #28a745;
        }

        .alert-error .alert-icon {
            color: #dc3545;
        }

        .alert-content {
            flex: 1;
            font-weight: 600;
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="jobs.php" class="back-link"><i class="fas fa-arrow-left"></i> Back</a>
        
        <div class="form-container">
            <h1>Post a Job</h1>
            <p class="subtitle">Share an exciting job opportunity with our community</p>

            <?php if ($message): ?>
                <div class="alert alert-success">
                    <div class="alert-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="alert-content"><?php echo htmlspecialchars($message); ?></div>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    <div class="alert-icon">
                        <i class="fas fa-exclamation-circle"></i>
                    </div>
                    <div class="alert-content"><?php echo htmlspecialchars($error); ?></div>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="job_title">Job Title: <span class="required">*</span></label>
                        <input type="text" id="job_title" name="job_title" value="<?php echo htmlspecialchars($_POST['job_title'] ?? ''); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="company_name">Company Name: <span class="required">*</span></label>
                        <input type="text" id="company_name" name="company_name" value="<?php echo htmlspecialchars($_POST['company_name'] ?? ''); ?>" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="job_type">Job Type: <span class="required">*</span></label>
                        <select id="job_type" name="job_type" required>
                            <option value="">Select Job Type</option>
                            <option value="Full-time" <?php echo ($_POST['job_type'] ?? '') === 'Full-time' ? 'selected' : ''; ?>>Full-time</option>
                            <option value="Part-time" <?php echo ($_POST['job_type'] ?? '') === 'Part-time' ? 'selected' : ''; ?>>Part-time</option>
                            <option value="Contract" <?php echo ($_POST['job_type'] ?? '') === 'Contract' ? 'selected' : ''; ?>>Contract</option>
                            <option value="Freelance" <?php echo ($_POST['job_type'] ?? '') === 'Freelance' ? 'selected' : ''; ?>>Freelance</option>
                            <option value="Internship" <?php echo ($_POST['job_type'] ?? '') === 'Internship' ? 'selected' : ''; ?>>Internship</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="location">Location: <span class="required">*</span></label>
                        <input type="text" id="location" name="location" value="<?php echo htmlspecialchars($_POST['location'] ?? ''); ?>" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="salary_min">Minimum Salary ($):</label>
                        <input type="number" id="salary_min" name="salary_min" step="100" value="<?php echo htmlspecialchars($_POST['salary_min'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="salary_max">Maximum Salary ($):</label>
                        <input type="number" id="salary_max" name="salary_max" step="100" value="<?php echo htmlspecialchars($_POST['salary_max'] ?? ''); ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Job Description: <span class="required">*</span></label>
                    <textarea id="description" name="description" required><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="skills_required">Required Skills (comma-separated):</label>
                    <textarea id="skills_required" name="skills_required" style="min-height: 100px;"><?php echo htmlspecialchars($_POST['skills_required'] ?? ''); ?></textarea>
                </div>

                <div class="button-group">
                    <button type="submit" class="btn btn-primary">Post Job</button>
                    <a href="jobs.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>