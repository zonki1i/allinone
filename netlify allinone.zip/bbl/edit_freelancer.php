<?php
session_start();
require 'config.php';

// Check if user is logged in and is a freelancer
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Fetch freelancer profile
$stmt = $conn->prepare("SELECT * FROM freelancers WHERE user_id = ?");
$stmt->execute([$user_id]);
$freelancer = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$freelancer) {
    $error = "Freelancer profile not found. Please register as a freelancer first.";
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error) {
    $name = trim($_POST['name'] ?? '');
    $surname = trim($_POST['surname'] ?? '');
    $specialty = trim($_POST['specialty'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $price_per_hour = trim($_POST['price_per_hour'] ?? '');
    $skills = trim($_POST['skills'] ?? '');
    $extra_info = trim($_POST['extra_info'] ?? '');
    $profile_pic = trim($_POST['profile_picture'] ?? '');

    if ($name && $surname && $specialty && $country && $price_per_hour) {
        $stmt = $conn->prepare("UPDATE freelancers SET name = ?, surname = ?, specialty = ?, country = ?, price = ?, skills = ?, additional = ?, avatar = ? WHERE user_id = ?");
        
        if ($stmt->execute([$name, $surname, $specialty, $country, $price_per_hour, $skills, $extra_info, $profile_pic, $user_id])) {
            $message = "Profile updated successfully!";
            // Refresh the freelancer data
            $stmt = $conn->prepare("SELECT * FROM freelancers WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $freelancer = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $error = "Failed to update profile.";
        }
    } else {
        $error = "Please fill in all required fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Freelancer Profile - ALLINONE</title>
    <!-- Google Font: Oswald (Variable) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Oswald", sans-serif;
            font-optical-sizing: auto;
            font-style: normal;
            background-color: #f5f7fb;
            color: #212529;
        }

        .container {
            width: 100%;
            max-width: 900px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .form-container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-bottom: 30px;
            color: #3a86ff;
            font-size: 2rem;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        @media (max-width: 600px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 700;
            color: #212529;
        }

        input[type="text"],
        input[type="number"],
        input[type="email"],
        input[type="url"],
        textarea,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            font-family: "Oswald", sans-serif;
        }

        textarea {
            min-height: 120px;
            resize: vertical;
        }

        input:focus,
        textarea:focus,
        select:focus {
            outline: none;
            border-color: #3a86ff;
            box-shadow: 0 0 5px rgba(58, 134, 255, 0.3);
        }

        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 30px;
        }

        button, .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            font-weight: 700;
            cursor: pointer;
            font-family: "Oswald", sans-serif;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3a86ff 0%, #1b63e8 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(58, 134, 255, 0.4);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        .message {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #3a86ff;
            text-decoration: none;
            font-weight: 600;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="freelancinglog.php" class="back-link"><i class="fas fa-arrow-left"></i> Back</a>
        
        <div class="form-container">
            <h1>Edit Your Freelancer Profile</h1>

            <?php if ($message): ?>
                <div class="message success"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="message error"><?php echo htmlspecialchars($error); ?></div>
            <?php else: ?>
                <form method="POST">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="name">First Name:</label>
                            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($freelancer['name'] ?? ''); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="surname">Last Name:</label>
                            <input type="text" id="surname" name="surname" value="<?php echo htmlspecialchars($freelancer['surname'] ?? ''); ?>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="specialty">Specialty:</label>
                            <input type="text" id="specialty" name="specialty" value="<?php echo htmlspecialchars($freelancer['specialty'] ?? ''); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="country">Country:</label>
                            <input type="text" id="country" name="country" value="<?php echo htmlspecialchars($freelancer['country'] ?? ''); ?>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="price_per_hour">Price per Hour ($):</label>
                            <input type="number" id="price_per_hour" name="price_per_hour" step="0.01" value="<?php echo htmlspecialchars($freelancer['price'] ?? ''); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="profile_picture">Profile Picture URL:</label>
                            <input type="url" id="profile_picture" name="profile_picture" value="<?php echo htmlspecialchars($freelancer['avatar'] ?? ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="skills">Skills (comma-separated):</label>
                        <textarea id="skills" name="skills"><?php echo htmlspecialchars($freelancer['skills'] ?? ''); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="extra_info">Additional Information:</label>
                        <textarea id="extra_info" name="extra_info"><?php echo htmlspecialchars($freelancer['additional'] ?? ''); ?></textarea>
                    </div>

                    <div class="button-group">
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                        <a href="freelancinglog.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
