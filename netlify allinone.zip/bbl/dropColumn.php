<?php
require 'config.php';


$sql = "ALTER TABLE users DROP COLUMN example_column";


if ($conn->query($sql) === TRUE) {
echo "Column dropped successfully";
} else {
echo "Error dropping column: " . $conn->error;
}
?>