<?php
require 'config.php';


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
header('Location: signUp.php');
exit;
}


$email = trim($_POST['email']);
$username = trim($_POST['username']);
$password = $_POST['password'];


if (empty($email) || empty($username) || empty($password)) {
header('Location: signUp.php?error=empty');
exit;
}


$hashedPassword = password_hash($password, PASSWORD_DEFAULT);


$stmt = $conn->prepare(
"INSERT INTO users (email, username, password) VALUES (?, ?, ?)"
);
$stmt->bind_param("sss", $email, $username, $hashedPassword);


if ($stmt->execute()) {
header('Location: login.php?signup=success');
exit;
} else {
header('Location: signUp.php?error=exists');
exit;
}