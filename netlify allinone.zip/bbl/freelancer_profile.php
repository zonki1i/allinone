<?php
session_start();

// Database connection
$host = "localhost";
$db   = "workdb";
$user = "root";
$pass = "";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Database connection failed");
}

// Get freelancer ID from URL
$freelancer_id = $_GET['id'] ?? null;

if (!$freelancer_id) {
    header("Location: findFreelancer.php");
    exit();
}

// Hardcoded freelancers
$hardcodedFreelancers = [
    -9 => [
        'id' => -9,
        'name' => 'Jeffrey',
        'surname' => 'Epstein',
        'specialty' => 'Cybersecurity Consultant',
        'country' => 'United States',
        'price' => '60',
        'skills' => 'Pen Testing, Security Audits',
        'avatar' => 'https://upload.wikimedia.org/wikipedia/commons/6/62/Jeffrey_Epstein_mug_shot.jpg',
        'additional' => 'Specialized in cybersecurity and penetration testing.'
    ],
    -12 => [
        'id' => -12,
        'name' => 'Benjamin',
        'surname' => 'Netanyahu',
        'specialty' => 'AI Engineer',
        'country' => 'Israel',
        'price' => '70',
        'skills' => 'Python, TensorFlow, Leadership',
        'avatar' => 'https://upload.wikimedia.org/wikipedia/commons/1/1c/Benjamin_Netanyahu_2019_%28cropped%29.jpg',
        'additional' => 'Expert in AI and machine learning technologies.'
    ]
];

// Check if it's a hardcoded freelancer
if (isset($hardcodedFreelancers[$freelancer_id])) {
    $freelancer = $hardcodedFreelancers[$freelancer_id];
} else {
    // Fetch freelancer from database
    $stmt = $conn->prepare("SELECT * FROM freelancers WHERE id = ?");
    $stmt->bind_param("i", $freelancer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $freelancer = $result->fetch_assoc();
}

if (!$freelancer) {
    header("Location: findFreelancer.php");
    exit();
}

// Process skills
$skills = $freelancer['skills'] ? array_filter(array_map('trim', explode(',', $freelancer['skills']))) : [];

// Determine current user and role
$current_user_id = $_SESSION['user_id'] ?? null;
$current_user_role = null;
$current_user_email = '';

if ($current_user_id) {
    $ur = $conn->prepare("SELECT role, email FROM users WHERE id = ?");
    $ur->bind_param("i", $current_user_id);
    $ur->execute();
    $urres = $ur->get_result();
    $urdata = $urres->fetch_assoc();
    $current_user_role = $urdata['role'] ?? null;
    $current_user_email = $urdata['email'] ?? '';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($freelancer['name'] . ' ' . $freelancer['surname']); ?> - Profile</title>
    <!-- Google Font: Oswald (Variable) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Oswald", sans-serif;
            background: linear-gradient(135deg, #f5f7fb 0%, #e3edff 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 30px;
            color: #3a86ff;
            text-decoration: none;
            font-weight: 700;
            transition: all 0.3s;
        }

        .back-link:hover {
            color: #1b63e8;
            transform: translateX(-5px);
        }

        .profile-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .header-section {
            background: linear-gradient(135deg, #3a86ff 0%, #8338ec 100%);
            padding: 60px 40px 40px;
            color: white;
            text-align: center;
            position: relative;
        }

        .avatar {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            border: 5px solid white;
            object-fit: cover;
            margin: 0 auto 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .name {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 10px;
            text-transform: capitalize;
        }

        .specialty {
            font-size: 1.4rem;
            opacity: 0.95;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .meta-info {
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
            margin-top: 25px;
            padding-top: 25px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }

        .meta-item {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .meta-label {
            font-size: 0.85rem;
            opacity: 0.85;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }

        .meta-value {
            font-size: 1.3rem;
            font-weight: 700;
        }

        .content-section {
            padding: 50px 40px;
        }

        .section {
            margin-bottom: 40px;
        }

        .section:last-child {
            margin-bottom: 0;
        }

        .section-title {
            font-size: 1.5rem;
            color: #3a86ff;
            margin-bottom: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title i {
            font-size: 1.3rem;
        }

        .skills-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 12px;
        }

        .skill-tag {
            background: linear-gradient(135deg, #e8f0ff 0%, #f0e8ff 100%);
            color: #3a86ff;
            padding: 12px 20px;
            border-radius: 25px;
            text-align: center;
            font-weight: 600;
            border: 2px solid #3a86ff;
            transition: all 0.3s;
        }

        .skill-tag:hover {
            background: linear-gradient(135deg, #3a86ff 0%, #8338ec 100%);
            color: white;
            transform: translateY(-3px);
        }

        .description {
            background: #f5f7fb;
            padding: 25px;
            border-radius: 12px;
            line-height: 1.8;
            color: #212529;
            border-left: 4px solid #3a86ff;
            font-size: 1rem;
        }

        .action-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-top: 40px;
            padding-top: 40px;
            border-top: 2px solid #e0e0e0;
        }

        .btn {
            padding: 16px 32px;
            border: none;
            border-radius: 10px;
            font-family: "Oswald", sans-serif;
            font-weight: 700;
            font-size: 1.05rem;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3a86ff 0%, #1b63e8 100%);
            color: white;
            box-shadow: 0 8px 25px rgba(58, 134, 255, 0.4);
        }

        .btn-primary:hover {
            transform: translateY(-3px) scale(1.02);
            box-shadow: 0 12px 35px rgba(58, 134, 255, 0.5);
        }

        .btn-primary:active {
            transform: translateY(-1px);
        }

        .btn-secondary {
            background: white;
            color: #3a86ff;
            border: 2px solid #3a86ff;
            box-shadow: 0 4px 15px rgba(58, 134, 255, 0.2);
        }

        .btn-secondary:hover {
            background: #f5f7fb;
            transform: translateY(-3px) scale(1.02);
            box-shadow: 0 12px 30px rgba(58,134,255,0.12);
        }

        /* Make the send/message button visually appealing */
        .btn-send {
            background: linear-gradient(135deg, #ff7a59 0%, #ff4d6d 100%);
            color: white;
            border: none;
        }

        .btn-send:hover {
            transform: translateY(-4px) scale(1.03);
            box-shadow: 0 14px 40px rgba(255,77,109,0.2);
        }

        .contact-info {
            background: linear-gradient(135deg, #e8f0ff 0%, #f0e8ff 100%);
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 25px;
        }

        .contact-item {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 15px;
            color: #212529;
        }

        .contact-item:last-child {
            margin-bottom: 0;
        }

        .contact-item i {
            font-size: 1.3rem;
            color: #3a86ff;
            min-width: 30px;
        }

        @media (max-width: 768px) {
            .header-section {
                padding: 40px 20px 30px;
            }

            .name {
                font-size: 1.8rem;
            }

            .specialty {
                font-size: 1.1rem;
            }

            .content-section {
                padding: 30px 20px;
            }

            .action-buttons {
                grid-template-columns: 1fr;
            }

            .meta-info {
                gap: 15px;
            }

            .section-title {
                font-size: 1.2rem;
            }

            .skills-grid {
                grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="findFreelancer.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Freelancers</a>

        <div class="profile-card">
            <!-- Header Section -->
            <div class="header-section">
                <img src="<?php echo htmlspecialchars($freelancer['avatar'] ?? 'https://via.placeholder.com/150?text=No+Picture'); ?>" alt="<?php echo htmlspecialchars($freelancer['name']); ?>" class="avatar">
                
                <div style="display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;">
                    <div class="name"><?php echo htmlspecialchars($freelancer['name'] . ' ' . $freelancer['surname']); ?></div>
                    <?php if ($current_user_role === 'business'): ?>
                        <a href="send_message.php?id=<?php echo $freelancer_id; ?>" title="Send message / Notification" style="text-decoration:none;">
                            
                        </a>
                    <?php endif; ?>
                </div>
                <div class="specialty"><?php echo htmlspecialchars($freelancer['specialty']); ?></div>
                
                <div class="meta-info">
                    <div class="meta-item">
                        <div class="meta-label">Rate</div>
                        <div class="meta-value">$<?php echo htmlspecialchars($freelancer['price']); ?>/hr</div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Country</div>
                        <div class="meta-value"><?php echo htmlspecialchars($freelancer['country']); ?></div>
                    </div>
                </div>
            </div>

            <!-- Content Section -->
            <div class="content-section">
                <!-- Skills Section -->
                <?php if (count($skills) > 0): ?>
                <div class="section">
                    <div class="section-title">
                        <i class="fas fa-star"></i>
                        Skills
                    </div>
                    <div class="skills-grid">
                        <?php foreach ($skills as $skill): ?>
                            <div class="skill-tag"><?php echo htmlspecialchars($skill); ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- About Section -->
                <?php if (!empty($freelancer['additional'])): ?>
                <div class="section">
                    <div class="section-title">
                        <i class="fas fa-info-circle"></i>
                        About
                    </div>
                    <div class="description">
                        <?php echo nl2br(htmlspecialchars($freelancer['additional'])); ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Action Buttons -->
                <div class="action-buttons">
                    <?php 
                    $isOwner = isset($_SESSION['user_id']) && isset($freelancer['user_id']) && intval($_SESSION['user_id']) === intval($freelancer['user_id']);
                    ?>
                    <?php if ($isOwner): ?>
                        <a href="editFreelancer.php?id=<?php echo $freelancer['id']; ?>" class="btn btn-primary">
                            <i class="fas fa-edit"></i> Edit Profile
                        </a>
                        <a href="deleteFreelancer.php?id=<?php echo $freelancer['id']; ?>" class="btn btn-secondary" onclick="return confirm('Delete your profile? This action cannot be undone.')">
                            <i class="fas fa-trash"></i> Delete Profile
                        </a>
                    <?php else: ?>
                        <?php if (!isset($_SESSION['user_id'])): ?>
                            <a href="login.php" class="btn btn-secondary">
                                <i class="fas fa-sign-in-alt"></i> Login to Email
                            </a>
                        <?php elseif ($current_user_role === 'business'): ?>
                            <button onclick="sendEmail()" type="button" class="btn btn-send" style="margin: 0 auto;">
                                <i class="fas fa-envelope-open-text"></i> Send Email
                            </button>
                        <?php else: ?>
                            <button class="btn btn-secondary" disabled style="margin: 0 auto;" title="Freelancers cannot message other freelancers">
                                <i class="fas fa-envelope"></i> Freelancers can't message other freelancers!
                            </button>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        function hireFreelancer() {
            alert('Thank you for your interest! The hiring process will be implemented soon.');
            // TODO: Implement actual hiring functionality
        }

        function sendEmail() {
            const email = "<?php echo htmlspecialchars($current_user_email); ?>";
            
            if (email) {
                // Copy email to clipboard
                navigator.clipboard.writeText(email).then(() => {
                    alert('Email copied to clipboard!');
                    // Open mail client
                    window.location.href = "mailto:" + email;
                }).catch(() => {
                    // If clipboard fails, just open mail client
                    alert('Opening email client...');
                    window.location.href = "mailto:" + email;
                });
            } else {
                alert('Email not available.');
            }
        }
    </script>
</body>
</html>