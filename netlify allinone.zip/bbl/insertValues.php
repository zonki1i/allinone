<?php
require 'config.php';


$email = 'test@example.com';
$username = 'testuser';
$password = password_hash('password123', PASSWORD_DEFAULT);


$stmt = $conn->prepare("INSERT INTO users (email, username, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $email, $username, $password);


if ($stmt->execute()) {
echo "User inserted successfully";
} else {
echo "Error: " . $stmt->error;
}
?>