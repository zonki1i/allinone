<?php
session_start();

// Database connection
$host = "localhost";
$db   = "workdb";
$user = "root";
$pass = "";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Database connection failed");
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get freelancer id either from GET or by user_id
$freelancer_id = $_GET['id'] ?? null;
if (!$freelancer_id) {
    // try find by user_id
    $q = $conn->prepare("SELECT id FROM freelancers WHERE user_id = ?");
    $q->bind_param("i", $user_id);
    $q->execute();
    $res = $q->get_result();
    if ($res && $res->num_rows > 0) {
        $r = $res->fetch_assoc();
        $freelancer_id = $r['id'];
    }
}

if (!$freelancer_id) {
    // No profile exists; redirect to registration
    header("Location: registerFreelancer.php");
    exit();
}

// Fetch freelancer and verify ownership
$stmt = $conn->prepare("SELECT * FROM freelancers WHERE id = ?");
$stmt->bind_param("i", $freelancer_id);
$stmt->execute();
$result = $stmt->get_result();
$freelancer = $result->fetch_assoc();

if (!$freelancer || intval($freelancer['user_id']) !== intval($user_id)) {
    header("Location: findFreelancer.php");
    exit();
}

$message = null;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name           = trim($_POST['name']);
    $surname        = trim($_POST['surname']);
    $specialty      = trim($_POST['specialty']);
    $country        = trim($_POST['country']);
    $price_per_hour = trim($_POST['price_per_hour']);
    $skills         = trim($_POST['skills']);
    $extra_info     = trim($_POST['extra_info']);

    // Handle profile picture upload
    $profile_pic = $freelancer['avatar'] ?? '';
    if (!empty($_FILES['profile_picture']['name'])) {
        $upload_dir = 'uploads/profiles/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        $file_name = basename($_FILES['profile_picture']['name']);
        $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array(strtolower($file_ext), $allowed_ext)) {
            $new_file_name = $user_id . '_' . time() . '.' . $file_ext;
            $upload_path = $upload_dir . $new_file_name;
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $upload_path)) {
                $profile_pic = $upload_path;
            }
        }
    }

    // If still no profile pic, generate letter avatar
    if (empty($profile_pic)) {
        $first_letter = strtoupper($name[0] ?? 'A');
        $colors = ['3a86ff', '8338ec', 'ff006e', 'fb5607', 'ffbe0b'];
        $color_index = (ord($first_letter) % count($colors));
        $bg_color = $colors[$color_index];
        $profile_pic = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='150' height='150'%3E%3Crect fill='%23{$bg_color}' width='150' height='150'/%3E%3Ctext x='50%25' y='50%25' font-size='60' font-weight='bold' fill='white' text-anchor='middle' dy='.3em' font-family='Arial'%3E{$first_letter}%3C/text%3E%3C/svg%3E";
    }

    $upd = $conn->prepare("UPDATE freelancers SET name = ?, surname = ?, specialty = ?, country = ?, price = ?, skills = ?, additional = ?, avatar = ? WHERE id = ?");
    $upd->bind_param("ssssdsssi", $name, $surname, $specialty, $country, $price_per_hour, $skills, $extra_info, $profile_pic, $freelancer_id);
    if ($upd->execute()) {
        header("Location: freelancer_profile.php?id=" . $freelancer_id);
        exit();
    } else {
        $message = 'Error updating profile.';
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Edit Freelancer Profile</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <style>
        body { font-family: "Oswald", sans-serif; background:#f5f7fb; color:#212529; padding:30px; }
        .container { max-width:900px; margin:0 auto; background:white; padding:30px; border-radius:12px; box-shadow:0 10px 30px rgba(0,0,0,0.08); }
        input, textarea { width:100%; padding:10px; margin-bottom:12px; border-radius:6px; border:1px solid #ddd; }
        button { padding:12px 20px; background:#3a86ff; color:white; border:none; border-radius:8px; cursor:pointer; }
    </style>
</head>
<body>
<div class="container">
    <a href="freelancer_profile.php?id=<?php echo $freelancer_id; ?>" style="text-decoration:none;color:#3a86ff;display:inline-block;margin-bottom:16px;">&larr; Back to Profile</a>
    <h1>Edit Your Freelancer Profile</h1>
    <?php if ($message): ?><div style="padding:10px;background:#ffecec;border-radius:6px;margin-bottom:12px;"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="name" placeholder="First Name" value="<?php echo htmlspecialchars($freelancer['name']); ?>" required>
        <input type="text" name="surname" placeholder="Last Name" value="<?php echo htmlspecialchars($freelancer['surname']); ?>" required>
        <input type="text" name="specialty" placeholder="Specialty" value="<?php echo htmlspecialchars($freelancer['specialty']); ?>" required>
        <input type="text" name="country" placeholder="Country" value="<?php echo htmlspecialchars($freelancer['country']); ?>" required>
        <input type="number" name="price_per_hour" placeholder="Price per Hour ($)" step="0.01" value="<?php echo htmlspecialchars($freelancer['price']); ?>" required>
        <input type="text" name="skills" placeholder="Skills (comma-separated)" value="<?php echo htmlspecialchars($freelancer['skills']); ?>" required>
        <input type="file" name="profile_picture" accept="image/jpeg,image/png,image/gif">
        <textarea name="extra_info" placeholder="Additional Information..."><?php echo htmlspecialchars($freelancer['additional']); ?></textarea>
        <button type="submit">Save Changes</button>
    </form>
</div>
</body>
</html>
