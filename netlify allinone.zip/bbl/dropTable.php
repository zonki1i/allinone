<?php
require 'config.php';


$sql = "DROP TABLE IF EXISTS users";


if ($conn->query($sql) === TRUE) {
echo "Table dropped successfully";
} else {
echo "Error dropping table: " . $conn->error;
}
?>