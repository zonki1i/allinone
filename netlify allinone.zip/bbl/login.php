<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ALLINONE</title>
    <!-- Google Font: Oswald (Variable) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
       * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: "Oswald", sans-serif;
    background: linear-gradient(135deg, #3a86ff 0%, #8338ec 100%);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    padding: 20px;
}

.logo {
    position: absolute;
    top: 30px;
    left: 30px;
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 1.5rem;
    font-weight: 700;
    color: white;
    text-decoration: none;
}

.logo i {
    font-size: 2rem;
}

.logo span {
    font-style: italic;
}

.card {
    width: 100%;
    max-width: 400px;
    padding: 40px 35px;
    border-radius: 15px;
    background-color: #fff;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
}

h2 {
    text-align: center;
    color: #3a86ff;
    margin-bottom: 10px;
    font-size: 1.8rem;
}

.subtitle {
    text-align: center;
    color: #6c757d;
    margin-bottom: 30px;
    font-size: 0.95rem;
}

input {
    width: 100%;
    padding: 14px;
    margin-bottom: 16px;
    border-radius: 8px;
    border: 1px solid #ddd;
    font-size: 15px;
    transition: border-color 0.3s;
}

input:focus {
    outline: none;
    border-color: #3a86ff;
}

button {
    width: 100%;
    padding: 14px;
    background: linear-gradient(135deg, #3a86ff, #8338ec);
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: transform 0.3s;
}

button:hover {
    transform: translateY(-2px);
}

.signup-link {
    margin-top: 20px;
    text-align: center;
    font-size: 14px;
    color: #6c757d;
}

.signup-link a {
    color: #3a86ff;
    text-decoration: none;
    font-weight: 600;
}

.error,
.success {
    text-align: center;
    margin-bottom: 14px;
    font-size: 14px;
}

.error {
    color: #e63946;
}

.success {
    color: #2a9d8f;
}


@media (max-width: 360px) {
    .card {
        padding: 24px 20px;
    }

    h2 {
        font-size: 1.4rem;
    }
}
    </style>
</head>
<body>
    <a href="index.php" class="logo">
        <i class="fas fa-briefcase"></i>
        ALL<span>IN</span>ONE
    </a>

    <div class="card">
        <h2>Welcome Back</h2>
        <p class="subtitle">Log in to your account</p>
        
        <?php if (isset($_GET['error'])): ?>
            <div class="error">Invalid username/email or password.</div>
        <?php endif; ?>
        
        <?php if (isset($_GET['signup']) && $_GET['signup'] === 'success'): ?>
            <div class="success">Account created successfully. Please log in.</div>
        <?php endif; ?>
        
        <form method="POST" action="loginLogic.php">
            <input type="text" name="username" placeholder="Username or Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Log In</button>
        </form>
        
        <div class="signup-link">
            Don't have an account? <a href="signUp.php">Sign up</a>
        </div>
    </div>
</body>
</html>