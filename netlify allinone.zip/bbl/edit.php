<?php
session_start();
require 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';
$job = null;

// Get job ID from URL
$job_id = $_GET['job_id'] ?? null;

if (!$job_id) {
    header("Location: jobs.php");
    exit();
}

// Fetch job details
try {
    $stmt = $conn->prepare("SELECT * FROM jobs WHERE id = ? AND user_id = ?");
    $stmt->execute([$job_id, $user_id]);
    $job = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$job) {
        header("Location: jobs.php");
        exit();
    }
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
    $job = null;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $job_title = trim($_POST['job_title'] ?? '');
    $company_name = trim($_POST['company_name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $salary_min = trim($_POST['salary_min'] ?? '');
    $salary_max = trim($_POST['salary_max'] ?? '');
    $job_type = trim($_POST['job_type'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $skills_required = trim($_POST['skills_required'] ?? '');

    if ($job_title && $company_name && $description && $job_type && $location) {
        try {
            $stmt = $conn->prepare("UPDATE jobs SET job_title = ?, company_name = ?, description = ?, salary_min = ?, salary_max = ?, job_type = ?, location = ?, skills_required = ? WHERE id = ? AND user_id = ?");

            if ($stmt->execute([$job_title, $company_name, $description, $salary_min ?: null, $salary_max ?: null, $job_type, $location, $skills_required, $job_id, $user_id])) {
                $message = "Job updated successfully!";
                // Refresh job data
                $stmt = $conn->prepare("SELECT * FROM jobs WHERE id = ? AND user_id = ?");
                $stmt->execute([$job_id, $user_id]);
                $job = $stmt->fetch(PDO::FETCH_ASSOC);
            } else {
                $error = "Failed to update job. Please try again.";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    } else {
        $error = "Please fill in all required fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Job - ALLINONE</title>
    <!-- Google Font: Oswald (Variable) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Oswald", sans-serif;
            font-optical-sizing: auto;
            font-style: normal;
            background-color: #f5f7fb;
            color: #212529;
        }

        .container {
            width: 100%;
            max-width: 900px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .form-container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-bottom: 10px;
            color: #3a86ff;
            font-size: 2rem;
        }

        .subtitle {
            color: #6c757d;
            margin-bottom: 30px;
            font-size: 1.1rem;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        @media (max-width: 600px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 700;
            color: #212529;
        }

        input[type="text"],
        input[type="number"],
        input[type="email"],
        textarea,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            font-family: "Oswald", sans-serif;
        }

        textarea {
            min-height: 150px;
            resize: vertical;
        }

        input:focus,
        textarea:focus,
        select:focus {
            outline: none;
            border-color: #3a86ff;
            box-shadow: 0 0 5px rgba(58, 134, 255, 0.3);
        }

        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 30px;
        }

        button, .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            font-weight: 700;
            cursor: pointer;
            font-family: "Oswald", sans-serif;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3a86ff 0%, #1b63e8 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(58, 134, 255, 0.4);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        .message {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #3a86ff;
            text-decoration: none;
            font-weight: 600;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        .required {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="jobs.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Jobs</a>

        <div class="form-container">
            <h1>Edit Job</h1>
            <p class="subtitle">Update your job listing details</p>

            <?php if ($message): ?>
                <div class="message success"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="message error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="job_title">Job Title: <span class="required">*</span></label>
                        <input type="text" id="job_title" name="job_title" value="<?php echo htmlspecialchars($job['job_title'] ?? ''); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="company_name">Company Name: <span class="required">*</span></label>
                        <input type="text" id="company_name" name="company_name" value="<?php echo htmlspecialchars($job['company_name'] ?? ''); ?>" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="job_type">Job Type: <span class="required">*</span></label>
                        <select id="job_type" name="job_type" required>
                            <option value="">Select Job Type</option>
                            <option value="Full-time" <?php echo ($job['job_type'] ?? '') === 'Full-time' ? 'selected' : ''; ?>>Full-time</option>
                            <option value="Part-time" <?php echo ($job['job_type'] ?? '') === 'Part-time' ? 'selected' : ''; ?>>Part-time</option>
                            <option value="Contract" <?php echo ($job['job_type'] ?? '') === 'Contract' ? 'selected' : ''; ?>>Contract</option>
                            <option value="Freelance" <?php echo ($job['job_type'] ?? '') === 'Freelance' ? 'selected' : ''; ?>>Freelance</option>
                            <option value="Internship" <?php echo ($job['job_type'] ?? '') === 'Internship' ? 'selected' : ''; ?>>Internship</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="location">Location: <span class="required">*</span></label>
                        <input type="text" id="location" name="location" value="<?php echo htmlspecialchars($job['location'] ?? ''); ?>" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="salary_min">Minimum Salary ($):</label>
                        <input type="number" id="salary_min" name="salary_min" step="100" value="<?php echo htmlspecialchars($job['salary_min'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="salary_max">Maximum Salary ($):</label>
                        <input type="number" id="salary_max" name="salary_max" step="100" value="<?php echo htmlspecialchars($job['salary_max'] ?? ''); ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Job Description: <span class="required">*</span></label>
                    <textarea id="description" name="description" required><?php echo htmlspecialchars($job['description'] ?? ''); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="skills_required">Required Skills (comma-separated):</label>
                    <textarea id="skills_required" name="skills_required" style="min-height: 100px;"><?php echo htmlspecialchars($job['skills_required'] ?? ''); ?></textarea>
                </div>

                <div class="button-group">
                    <button type="submit" class="btn btn-primary">Update Job</button>
                    <a href="jobs.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
