<?php
require_once 'config.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS reviews (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        role VARCHAR(50) NOT NULL,
        rating INT NOT NULL,
        review TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=MyISAM";
    $conn->exec($sql);
    echo "Reviews table created successfully!\n";
} catch (PDOException $e) {
    echo "Error creating reviews table: " . $e->getMessage() . "\n";
}
?>
