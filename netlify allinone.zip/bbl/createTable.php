<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "workdb";

// Connect without specifying database
$conn = new mysqli($host, $user, $pass);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS $db";
if ($conn->query($sql) === TRUE) {
    echo "Database '$db' created successfully or already exists!<br>";
} else {
    echo "Error creating database: " . $conn->error . "<br>";
}

// Select the database
$conn->select_db($db);

// Create users table with role column
$sql = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if ($conn->query($sql)) {
    echo "Users table created successfully!<br>";
} else {
    echo "Error creating users table: " . $conn->error . "<br>";
}

// Add role column if it doesn't exist
if (!columnExists($conn, 'users', 'role')) {
    $alterSql = "ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'user'";
    if ($conn->query($alterSql)) {
        echo "Role column added successfully!<br>";
    } else {
        echo "Error adding role column: " . $conn->error . "<br>";
    }
} else {
    echo "Role column already exists!<br>";
}

// Add avatar column to freelancers if it doesn't exist
if (tableExists($conn, 'freelancers') && !columnExists($conn, 'freelancers', 'avatar')) {
    $alterSql = "ALTER TABLE freelancers ADD COLUMN avatar VARCHAR(255)";
    if ($conn->query($alterSql)) {
        echo "Avatar column added successfully!<br>";
    } else {
        echo "Error adding avatar column: " . $conn->error . "<br>";
    }
}

// Add user_id column to freelancers if it doesn't exist
if (tableExists($conn, 'freelancers') && !columnExists($conn, 'freelancers', 'user_id')) {
    $alterSql = "ALTER TABLE freelancers ADD COLUMN user_id INT";
    if ($conn->query($alterSql)) {
        echo "User ID column added to freelancers table successfully!<br>";
    } else {
        echo "Error adding user_id column: " . $conn->error . "<br>";
    }
} else {
    echo "User ID column already exists in freelancers table!<br>";
}

// Create reviews table
$sql = "CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL,
    rating INT NOT NULL,
    review TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if ($conn->query($sql)) {
    echo "Reviews table created successfully!<br>";
} else {
    echo "Error creating reviews table: " . $conn->error . "<br>";
}

// Create jobs table
$sql = "CREATE TABLE IF NOT EXISTS jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    job_title VARCHAR(255) NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    description LONGTEXT NOT NULL,
    salary_min DECIMAL(10, 2),
    salary_max DECIMAL(10, 2),
    job_type VARCHAR(100) NOT NULL,
    location VARCHAR(255) NOT NULL,
    skills_required TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
)";
if ($conn->query($sql)) {
    echo "Jobs table created successfully!<br>";
} else {
    echo "Error creating jobs table: " . $conn->error . "<br>";
}

// Helper function to check if a column exists
function columnExists($conn, $table, $column) {
    $result = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    return $result && $result->num_rows > 0;
}

// Helper function to check if a table exists
function tableExists($conn, $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    return $result && $result->num_rows > 0;
}

echo "Tables created/updated successfully!";
$conn->close();
?>