<?php session_start(); ?>

<?php if (isset($_GET['freelancer_success'])): ?>
<script>
    alert('Freelancer profile created successfully!');
</script>
<?php endif; ?>

<?php
require 'config.php';
// Determine current user's role (if logged in)
$current_role = null;
if (isset($_SESSION['user_id'])) {
    try {
        $ur = $conn->prepare("SELECT role FROM users WHERE id = ?");
        $ur->execute([$_SESSION['user_id']]);
        $ud = $ur->fetch(PDO::FETCH_ASSOC);
        $current_role = $ud['role'] ?? null;
    } catch (Exception $e) {
        $current_role = null;
    }
}
// Allow a session override for preview/testing without DB changes
if (!empty($_SESSION['role_override'])) {
    $current_role = $_SESSION['role_override'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Google Font: Oswald (Variable) -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ALLINONE - Marketplace for freelancers, full-time, and B2B</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: "Oswald", sans-serif;
    font-optical-sizing: auto;
    font-style: normal;
}


        :root {
            --primary-color: #3a86ff;
            --secondary-color: #8338ec;
            --accent-color: #ff006e;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --gray-color: #6c757d;
            --success-color: #38b000;
        }

        body {
            line-height: 1.6;
            color: var(--dark-color);
            background-color: #f5f7fb;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header */
        header {
            background-color: #f5f7fb;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-color);
            text-decoration: none;
        }

        .logo span {
            color: var(--secondary-color);
        }

        .logo i {
            font-size: 2rem;
        }

        nav ul {
            display: flex;
            list-style: none;
            gap: 30px;
        }

        nav a {
            text-decoration: none;
            color: var(--dark-color);
            font-weight: 600;
            transition: color 0.3s;
        }

        nav a:hover {
            color: var(--primary-color);
        }

        .cta-button {
            background-color: var(--primary-color);
            color: white;
            padding: 10px 25px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            transition: background-color 0.3s;
        }

        .cta-button:hover {
            background-color: var(--secondary-color);
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--dark-color);
            cursor: pointer;
        }

        .profile-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            position: relative;
            transition: background-color 0.3s;
        }

        .profile-icon:hover {
            background-color: var(--secondary-color);
        }

        .profile-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            min-width: 180px;
            display: none;
            z-index: 1000;
        }

        .profile-dropdown.active {
            display: block;
        }

        .profile-dropdown a {
            display: block;
            padding: 12px 16px;
            color: var(--dark-color);
            text-decoration: none;
            font-weight: 500;
            border-bottom: 1px solid #eee;
            transition: background-color 0.3s;
        }

        .profile-dropdown a:last-child {
            border-bottom: none;
        }

        .profile-dropdown a:hover {
            background-color: #f5f7fb;
            color: var(--primary-color);
        }

        .profile-icon::before {
            content: "";
            display: none;
        }

        .profile-icon:hover::before {
            display: none;
        }

        /* Hero Section */
        .hero {
            padding: 80px 0;
            background: linear-gradient(135deg, #3a86ff 0%, #8338ec 100%);
            text-align: center;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            color: white;
        }

        .hero p {
            font-size: 1.2rem;
            color: rgba(255, 255, 255, 0.9);
            max-width: 700px;
            margin: 0 auto 40px;
        }

        .highlight {
            color: white;
            font-weight: 700;
        }

        /* Find It Fast Section */
        .find-fast {
            padding: 60px 0;
            text-align: center;
            background-color: white;
        }

        .find-fast h2 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: var(--dark-color);
        }

        .find-fast .subtitle {
            font-size: 1.2rem;
            color: var(--gray-color);
            margin-bottom: 40px;
        }

        .stats-container {
            display: flex;
            justify-content: center;
            gap: 50px;
            margin-top: 40px;
            flex-wrap: wrap;
        }

        .stat-box {
            background-color: var(--light-color);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            min-width: 200px;
        }

        .stat-box i {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: var(--primary-color);
        }

        .stat-box h3 {
            font-size: 2.5rem;
            color: var(--secondary-color);
            margin-bottom: 5px;
        }

        .stat-box p {
            color: var(--gray-color);
            font-weight: 600;
        }

        

        /* Who is it for Section */
        .who-for {
            padding: 80px 0;
            background-color: #f8f9fa;
        }

        .who-for h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: var(--dark-color);
        }

        .who-for > p {
            text-align: center;
            color: var(--gray-color);
            font-size: 1.2rem;
            margin-bottom: 60px;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }

        .communities {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
            justify-content: center;
        }

        .community-card {
            flex: 1;
            min-width: 300px;
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s;
        }

        .community-card:hover {
            transform: translateY(-10px);
        }

        .card-header {
            padding: 25px;
            color: white;
            text-align: center;
        }

        .freelancers .card-header {
            background: linear-gradient(135deg, #3a86ff 0%, #8338ec 100%);
        }

        .job-seekers .card-header {
            background: linear-gradient(135deg, #8338ec 0%, #3a86ff 100%);
        }

        .businesses .card-header {
            background: linear-gradient(135deg, #8338ec 0%, #ff006e 100%);
        }

        .card-header h3 {
            font-size: 1.8rem;
            margin-bottom: 10px;
        }

        .card-body {
            padding: 30px;
        }

        .card-body p {
            color: var(--gray-color);
            margin-bottom: 20px;
        }

        .card-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: transparent;
            border: 2px solid;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }

        .freelancers .card-button {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .job-seekers .card-button {
            color: var(--secondary-color);
            border-color: var(--secondary-color);
        }

        .businesses .card-button {
            color: var(--secondary-color);
            border-color: var(--secondary-color);
        }

        .card-button:hover {
            color: white;
        }

        .freelancers .card-button:hover {
            background-color: var(--primary-color);
        }

        .job-seekers .card-button:hover {
            background-color: var(--secondary-color);
        }

        .businesses .card-button:hover {
            background-color: var(--accent-color);
        }

        /* Role Cards Section */
        .role-cards-section {
            padding: 40px 0;
            background-color: white;
        }

        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 20px;
            max-width: 1100px;
            margin: 0 auto;
        }

        .role-card {
            background: linear-gradient(135deg, #007bff 0%, #8a2be2 100%);
            color: white;
            padding: 22px;
            border-radius: 12px;
            display: flex;
            gap: 18px;
            align-items: center;
            text-decoration: none;
            box-shadow: 0 12px 30px rgba(51, 51, 102, 0.12);
            transition: transform 0.18s, box-shadow 0.18s;
        }

        .role-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 18px 46px rgba(51, 51, 102, 0.18);
        }

        .role-icon {
            background: rgba(255, 255, 255, 0.12);
            color: white;
            padding: 14px;
            border-radius: 10px;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 56px;
            height: 56px;
            flex-shrink: 0;
        }

        .role-content {
            flex: 1;
        }

        .role-title {
            font-weight: 800;
            font-size: 1.05rem;
            color: #ffffff;
            margin-bottom: 4px;
        }

        .role-desc {
            color: rgba(255, 255, 255, 0.9);
            font-size: 0.95rem;
            opacity: 0.95;
        }

        .role-cta {
            color: rgba(255, 255, 255, 0.95);
            font-size: 1.05rem;
            flex-shrink: 0;
        }

        /* Platform Section */
        .platform {
            padding: 60px 0;
            background-color: white;
            text-align: center;
        }

        .platform h2 {
            font-size: 2.5rem;
            margin-bottom: 40px;
            color: var(--dark-color);
        }

        .platform-features {
            display: flex;
            justify-content: center;
            gap: 50px;
            flex-wrap: wrap;
        }

        .feature {
            flex: 1;
            min-width: 250px;
            max-width: 300px;
        }

        .feature i {
            font-size: 3rem;
            color: var(--primary-color);
            margin-bottom: 20px;
        }

        .feature h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .feature p {
            color: var(--gray-color);
        }

        /* Updated Footer Styles - BIGGER WAVE */
        /* Footer */
footer {
    position: relative;
    color: white;
    background: linear-gradient(135deg, #3a86ff 0%, #8338ec 100%); /* Wave provides the color */
    overflow: hidden;
}

.footer-wave {
    position: absolute;
    top: -150px; /* Adjust to match wave size */
    left: 0;
    width: 100%;
    height: 150px;
    z-index: 1;
}

.footer-wave svg {
    width: 100%;
    height: 100%;
}

.footer-content-wrapper {
    position: relative;
    z-index: 2; /* Makes content appear above the SVG */
    padding: 60px 0 40px;
}

.footer-columns {
    display: flex;
    flex-wrap: wrap;
    gap: 50px;
    margin-bottom: 40px;
}

.footer-column {
    flex: 1;
    min-width: 200px;
}

.footer-column h3 {
    font-size: 1.3rem;
    margin-bottom: 20px;
    color: white;
}

.footer-column ul {
    list-style: none;
}

.footer-column ul li {
    margin-bottom: 10px;
}

.footer-column a {
    color: rgba(255, 255, 255, 0.8);
    text-decoration: none;
    transition: color 0.3s;
}

.footer-column a:hover {
    color: white;
}

.notice {
    background-color: rgba(255, 255, 255, 0.1);
    padding: 15px;
    border-radius: 5px;
    margin-top: 20px;
    font-size: 0.9rem;
    color: rgba(255, 255, 255, 0.8);
}

.copyright {
    text-align: center;
    padding-top: 30px;
    border-top: 1px solid rgba(255, 255, 255, 0.2);
    color: rgba(255, 255, 255, 0.8);
    font-size: 0.9rem;
}

/* Responsive */
@media (max-width: 992px) {
    .footer-columns {
        gap: 30px;
    }
    footer {
        padding-top: 120px;
    }
    .footer-wave {
        top: -120px;
        height: 120px;
    }
}

@media (max-width: 768px) {
    .footer-columns {
        flex-direction: column;
        gap: 40px;
    }
    .footer-column {
        min-width: 100%;
    }
    footer {
        padding-top: 100px;
    }
    .footer-wave {
        top: -100px;
        height: 100px;
    }
}


        @media (max-width: 768px) {
            .header-content {
                flex-wrap: wrap;
            }
            
            nav {
                display: none;
                width: 100%;
                order: 3;
                margin-top: 20px;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 15px;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            .hero h1 {
                font-size: 2rem;
            }
            
            .find-fast h2, .who-for h2, .platform h2 {
                font-size: 2rem;
            }
            
            .stats-container {
                flex-direction: column;
                align-items: center;
            }

            .cards-grid {
                grid-template-columns: 1fr;
            }

            .role-card {
                padding: 16px;
            }
            
            .footer-columns {
                flex-direction: column;
                gap: 40px;
            }
            
            .footer-column {
                min-width: 100%;
            }
            
            /* Adjust wave for mobile */
            footer {
                padding-top: 100px;
            }

            .spacer{
                aspect-ratio: 960/540;
                width: 100%;
                background-repeat: no-repeat;
                background-position: center;
                background-size: cover;
            }

            .layer1 {
                background-image: url ('img/wave.png');
            }
            
            .footer-wave {
                top: -100px;
                height: 100px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <a href="#" class="logo">
                    <i class="fas fa-briefcase"></i>
                    ALL<span>IN</span>ONE
                </a>
                
                <button class="mobile-menu-btn" id="mobileMenuBtn">
                    <i class="fas fa-bars"></i>
                </button>
                
                <nav id="mainNav">
                    <ul>
                       <li><a href="freelancinglog.php">Freelancers</a></li>
                        <li><a href="jobs.php">Jobs</a></li>
                        <li><a href="hirelog.php">Hire</a></li>
                        <li><a href="reviewslog.php">Reviews</a></li>
                    </ul>
                </nav>
                
                <div class="profile-icon" id="profileIcon">
                    <i class="fas fa-user"></i>
                    <div class="profile-dropdown" id="profileDropdown">
                        <a href="accSettings.php">Account Settings</a>
                        <a href="logout.php">Log out</a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Marketplace for <span class="highlight">freelancers</span>, <span class="highlight">full-time</span>, and <span class="highlight">B2B</span></h1>
            <p>Connect, collaborate, and succeed with our platform that brings together three distinct communities to help you find what you need faster than ever.</p>
            <a href="#find-fast" class="cta-button">Explore Now</a>
        </div>
    </section>

    <!-- Find It Fast Section -->
    <section class="find-fast" id="find-fast">
        <div class="container">
            <h2>Find It Fast</h2>
            <p class="subtitle">If it takes more than 7 seconds, it's too slow.</p>
            
            <div class="stats-container">
                <div class="stat-box">
                    <i class="fas fa-users"></i>
                    <h3>151</h3>
                    <p>PEOPLE</p>
                </div>
                
                <div class="stat-box">
                    <i class="fas fa-building"></i>
                    <h3>43</h3>
                    <p>BUSINESSES</p>
                </div>
                
                <div class="stat-box">
                    <i class="fas fa-briefcase"></i>
                    <h3>87</h3>
                    <p>JOBS</p>
                </div>
            </div>
            
            
        </div>
    </section>

    <!-- Role Cards Section -->
    <section class="role-cards-section">
        <div class="container">
            <div class="cards-grid">
                <?php
                    // Show appropriate cards based on role
                    // Only business users and non-logged-in users can see the post job card
                    // Freelancers and job seekers should NOT see it
                    $show_businesses = ($current_role === 'business' || !$current_role);
                    $show_freelancers = true; // Everyone can see freelancers
                    $show_job_seekers = true; // Everyone can see job listings
                ?>
                
                <?php if ($show_businesses): ?>
                    <a href="post_job.php" class="role-card" aria-label="Businesses">
                        <div class="role-icon"><i class="fas fa-briefcase"></i></div>
                        <div class="role-content">
                            <div class="role-title">Businesses</div>
                            <div class="role-desc">Find talent or discover B2B opportunities.</div>
                        </div>
                        <div class="role-cta"><i class="fas fa-arrow-right"></i></div>
                    </a>
                <?php endif; ?>
                
                <?php if ($show_freelancers): ?>
                    <a href="freelancinglog.php" class="role-card" aria-label="Freelancers">
                        <div class="role-icon"><i class="fas fa-user-tie"></i></div>
                        <div class="role-content">
                            <div class="role-title">Freelancers</div>
                            <div class="role-desc">Hire freelancers or offer your skills.</div>
                        </div>
                        <div class="role-cta"><i class="fas fa-arrow-right"></i></div>
                    </a>
                <?php endif; ?>
                
                <?php if ($show_job_seekers): ?>
                    <a href="jobs.php" class="role-card" aria-label="Job Seekers">
                        <div class="role-icon"><i class="fas fa-users"></i></div>
                        <div class="role-content">
                            <div class="role-title">Jobs</div>
                            <div class="role-desc">Find full-time and part-time jobs.</div>
                        </div>
                        <div class="role-cta"><i class="fas fa-arrow-right"></i></div>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Platform Section -->
    <section class="platform" id="platform">
        <div class="container">
            <h2>Platform</h2>
            <div class="platform-features">
                <div class="feature">
                    <i class="fas fa-user-friends"></i>
                    <h3>People</h3>
                    <p>Connect with skilled professionals and find the perfect match for your project or team.</p>
                </div>
                
                <div class="feature">
                    <i class="fas fa-briefcase"></i>
                    <h3>Jobs</h3>
                    <p>Discover full-time, part-time, and freelance opportunities that align with your career path.</p>
                </div>
                
                <div class="feature">
                    <i class="fas fa-building"></i>
                    <h3>Businesses</h3>
                    <p>Find B2B services, partnerships, and resources to help your business thrive.</p>
                </div>
            </div>
        </div>
    </section>

    <div class="spacer layer1"></div>


<footer id="legal">
    

    <div class="container footer-content-wrapper">
        <div class="footer-columns">
            <!-- About Us -->
            <div class="footer-column">
                <h3>About Us</h3>
                <ul>
                    <li><a href="#">Our Mission</a></li>
                    <li><a href="#">Team</a></li>
                    <li><a href="#">Careers</a></li>
                    <li><a href="#">Press</a></li>
                </ul>
            </div>

            <!-- For Freelancers -->
            <div class="footer-column">
                <h3>For Freelancers</h3>
                <ul>
                    <li><a href="#">Find Projects</a></li>
                    <li><a href="#">Build Portfolio</a></li>
                    <li><a href="#">Freelancer Resources</a></li>
                    <li><a href="#">Community</a></li>
                </ul>
            </div>

            <!-- For Businesses -->
            <div class="footer-column">
                <h3>For Businesses</h3>
                <ul>
                    <li><a href="#">Hire Talent</a></li>
                    <li><a href="#">Post Projects</a></li>
                    <li><a href="#">B2B Services</a></li>
                    <li><a href="#">Enterprise Solutions</a></li>
                </ul>
            </div>

            <!-- Legal -->
            <div class="footer-column">
                <h3>Legal</h3>
                <ul>
                    <li><a href="#">Terms of Service</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Cookie Policy</a></li>
                    <li><a href="#">GDPR</a></li>
                </ul>
                <div class="notice">
                    <p>allinone.com is a platform connecting freelancers, job seekers, and businesses. We do not charge any commission fees.</p>
                </div>
            </div>
        </div>

        <div class="copyright">
            &copy; 2025 allinone.com. All rights reserved.
        </div>
    </div>
</footer>



    <script>
    // Profile dropdown toggle
    const profileIcon = document.getElementById('profileIcon');
    const profileDropdown = document.getElementById('profileDropdown');

    profileIcon.addEventListener('click', (e) => {
        e.stopPropagation();
        profileDropdown.classList.toggle('active');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', () => {
        profileDropdown.classList.remove('active');
    });

    // Mobile menu toggle
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mainNav = document.getElementById('mainNav');

    mobileMenuBtn.addEventListener('click', () => {
        mainNav.classList.toggle('active');
        const icon = mobileMenuBtn.querySelector('i');
        icon.classList.toggle('fa-bars');
        icon.classList.toggle('fa-times');
    });

    // Smooth scrolling ONLY for real hash links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');

            if (targetId === '#') return; // allow normal click

            e.preventDefault();
            const target = document.querySelector(targetId);
            if (!target) return;

            window.scrollTo({
                top: target.offsetTop - 80,
                behavior: 'smooth'
            });
        });
    });
</script>

</body>
</html>