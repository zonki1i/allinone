<?php
session_start();
require_once 'config.php';

// Fetch reviews from database
$stmt = $conn->prepare("SELECT * FROM reviews ORDER BY created_at DESC");
$stmt->execute();
$reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Function to generate stars
function generateStars($rating) {
    $stars = '';
    for ($i = 1; $i <= 5; $i++) {
        if ($i <= $rating) {
            $stars .= '<i class="fas fa-star"></i>';
        } elseif ($i - 0.5 <= $rating) {
            $stars .= '<i class="fas fa-star-half-alt"></i>';
        } else {
            $stars .= '<i class="far fa-star"></i>';
        }
    }
    return $stars;
}

// Function to get initials
function getInitials($name) {
    $parts = explode(' ', $name);
    $initials = '';
    foreach ($parts as $part) {
        $initials .= strtoupper(substr($part, 0, 1));
    }
    return $initials;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reviews - ALLINONE</title>
    <!-- Google Font: Oswald (Variable) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Oswald", sans-serif;
            font-optical-sizing: auto;
            font-style: normal;
        }

        :root {
            --primary-color: #3a86ff;
            --secondary-color: #3a86ff;
            --accent-color: #3a86ff;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --gray-color: #6c757d;
            --success-color: #38b000;
        }

        body {
            line-height: 1.6;
            color: var(--dark-color);
            background-color: #f5f7fb;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header */
        header {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-color);
            text-decoration: none;
        }

        .logo span {
            color: var(--secondary-color);
        }

        .logo i {
            font-size: 2rem;
        }

        nav ul {
            display: flex;
            list-style: none;
            gap: 30px;
        }

        nav a {
            text-decoration: none;
            color: var(--dark-color);
            font-weight: 600;
            transition: color 0.3s;
        }

        nav a:hover {
            color: var(--primary-color);
        }

        .cta-button {
            background-color: var(--primary-color);
            color: white;
            padding: 10px 25px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            transition: background-color 0.3s;
        }

        .cta-button:hover {
            background-color: var(--secondary-color);
        }

        .profile-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            position: relative;
            transition: background-color 0.3s;
        }

        .profile-icon:hover {
            background-color: var(--secondary-color);
        }

        .profile-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            min-width: 180px;
            display: none;
            z-index: 1000;
        }

        .profile-dropdown.active {
            display: block;
        }

        .profile-dropdown a {
            display: block;
            padding: 12px 16px;
            color: var(--dark-color);
            text-decoration: none;
            font-weight: 500;
            border-bottom: 1px solid #eee;
            transition: background-color 0.3s;
        }

        .profile-dropdown a:last-child {
            border-bottom: none;
        }

        .profile-dropdown a:hover {
            background-color: #f5f7fb;
            color: var(--primary-color);
        }

        .profile-icon::before {
            content: "";
            display: none;
        }

        .profile-icon:hover::before {
            display: none;
        }

        /* Hero Section */
        .hero {
            padding: 80px 0;
            background: linear-gradient(135deg, #f5f7fb 0%, #e3edff 100%);
            text-align: center;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            color: var(--dark-color);
        }

        .hero p {
            font-size: 1.2rem;
            color: var(--gray-color);
            max-width: 700px;
            margin: 0 auto 40px;
        }

        /* Reviews Section */
        .reviews-section {
            padding: 60px 0;
            background-color: white;
        }

        .reviews-section h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 40px;
            color: var(--dark-color);
        }

        .reviews-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-bottom: 60px;
        }

        .review-card {
            background-color: var(--light-color);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .review-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .review-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            margin-right: 15px;
        }

        .review-info h4 {
            margin-bottom: 5px;
            color: var(--dark-color);
        }

        .review-stars {
            color: #ffd700;
            margin-bottom: 15px;
        }

        .review-text {
            color: var(--gray-color);
            line-height: 1.6;
        }

        /* Submit Review Section */
        .submit-review {
            max-width: 800px;
            margin: 0 auto;
            background-color: var(--light-color);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .submit-review h3 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--dark-color);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: var(--dark-color);
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .form-group textarea {
            height: 120px;
            resize: vertical;
        }

        .submit-btn {
            background-color: var(--primary-color);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 30px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }

        .submit-btn:hover {
            background-color: var(--secondary-color);
        }

        .delete-btn {
            background-color: #dc3545;
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 30px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
            margin-top: 20px;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        .login-message {
            text-align: center;
            padding: 20px;
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .login-message p {
            margin-bottom: 15px;
            color: #856404;
            font-weight: 600;
        }

        .login-btn {
            display: inline-block;
            background-color: var(--primary-color);
            color: white;
            padding: 12px 25px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 600;
            transition: background-color 0.3s;
        }

        .login-btn:hover {
            background-color: var(--secondary-color);
        }

        .message {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .message.success {
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }

        .message.error {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }

        /* Footer */
        footer {
            background-color: var(--dark-color);
            color: white;
            padding: 40px 0;
            text-align: center;
        }

        @media (max-width: 768px) {
            .hero h1 {
                font-size: 2rem;
            }

            .reviews-section h2 {
                font-size: 2rem;
            }

            .submit-review {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <a href="index.php" class="logo">
                    <i class="fas fa-briefcase"></i>
                    ALL<span>IN</span>ONE
                </a>

                <nav>
                    <ul>
                        <li><a href="indexlog.php">Home</a></li>
                        <li><a href="freelancinglog.php">Freelancers</a></li>
                        <li><a href="jobslog.php">Jobs</a></li>
                        <li><a href="hirelog.php">Hire</a></li>
                        <li><a href="reviewslog.php">Reviews</a></li>
                    </ul>
                </nav>

                <div class="profile-icon" id="profileIcon">
                    <i class="fas fa-user"></i>
                    <div class="profile-dropdown" id="profileDropdown">
                        <a href="accSettings.php">Account Settings</a>
                        <a href="logout.php">Log out</a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>User Reviews</h1>
            <p>See what our community has to say about their experiences on our platform. Real feedback from real users.</p>
        </div>
    </section>

    <!-- Reviews Section -->
    <section class="reviews-section">
        <div class="container">
            <h2>What Our Users Say</h2>
            <button id="showReviewsBtn" class="show-reviews-btn">Show Reviews</button>
            <div class="reviews-grid" id="reviewsGrid" style="display: none;">
                <?php foreach ($reviews as $review): ?>
                    <div class="review-card">
                        <div class="review-header">
                            <div class="review-avatar"><?php echo getInitials($review['name']); ?></div>
                            <div class="review-info">
                                <h4><?php echo htmlspecialchars($review['name']); ?></h4>
                                <p><?php echo htmlspecialchars($review['role']); ?></p>
                            </div>
                        </div>
                        <div class="review-stars">
                            <?php echo generateStars($review['rating']); ?>
                        </div>
                        <p class="review-text"><?php echo htmlspecialchars($review['review']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="submit-review">
                <h3>Share Your Experience</h3>
                <?php if (isset($_GET['sent']) && $_GET['sent'] == '1'): ?>
                    <div class="message success">
                        <p>Thank you for your review! It has been submitted successfully.</p>
                    </div>
                <?php elseif (isset($_GET['error']) && $_GET['error'] == '1'): ?>
                    <div class="message error">
                        <p>There was an error submitting your review. Please try again.</p>
                    </div>
                <?php endif; ?>
                <form action="submit_review.php" method="POST">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" placeholder="Your Name" required>
                    </div>

                    <div class="form-group">
                        <label for="role">Your Role</label>
                        <select id="role" name="role" required>
                            <option value="">Select Role</option>
                            <option value="freelancer">Freelancer</option>
                            <option value="business">Business Owner</option>
                            <option value="job-seeker">Job Seeker</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="rating">Rating</label>
                        <select id="rating" name="rating" required>
                            <option value="">Select Rating</option>
                            <option value="5">5 Stars</option>
                            <option value="4">4 Stars</option>
                            <option value="3">3 Stars</option>
                            <option value="2">2 Stars</option>
                            <option value="1">1 Star</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="review">Your Review</label>
                        <textarea id="review" name="review" placeholder="Share your experience..." required></textarea>
                    </div>

                    <button type="submit" class="submit-btn">Submit Review</button>
                </form>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer id="legal">
        <div class="container footer-content-wrapper">
            <div class="footer-columns">
                <!-- About Us -->
                <div class="footer-column">
                    <h3>About Us</h3>
                    <ul>
                        <li><a href="#">Our Mission</a></li>
                        <li><a href="#">Team</a></li>
                        <li><a href="#">Careers</a></li>
                        <li><a href="#">Press</a></li>
                    </ul>
                </div>

                <!-- For Freelancers -->
                <div class="footer-column">
                    <h3>For Freelancers</h3>
                    <ul>
                        <li><a href="#">Find Projects</a></li>
                        <li><a href="#">Build Portfolio</a></li>
                        <li><a href="#">Freelancer Resources</a></li>
                        <li><a href="#">Community</a></li>
                    </ul>
                </div>

                <!-- For Businesses -->
                <div class="footer-column">
                    <h3>For Businesses</h3>
                    <ul>
                        <li><a href="#">Hire Talent</a></li>
                        <li><a href="#">Post Projects</a></li>
                        <li><a href="#">B2B Services</a></li>
                        <li><a href="#">Enterprise Solutions</a></li>
                    </ul>
                </div>

                <!-- Legal -->
                <div class="footer-column">
                    <h3>Legal</h3>
                    <ul>
                        <li><a href="#">Terms of Service</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Cookie Policy</a></li>
                        <li><a href="#">GDPR</a></li>
                    </ul>
                    <div class="notice">
                        <p>allinone.com is a platform connecting freelancers, job seekers, and businesses. We do not charge any commission fees.</p>
                    </div>
                </div>
            </div>

            <div class="copyright">
                &copy; 2025 allinone.com. All rights reserved.
            </div>
        </div>
    </footer>

    <style>
        /* Footer Styles */
        footer {
            position: relative;
            color: white;
            background-color: blue;
            overflow: hidden;
        }

        .footer-wave {
            position: absolute;
            top: -150px;
            left: 0;
            width: 100%;
            height: 150px;
            z-index: 1;
        }

        .footer-wave svg {
            width: 100%;
            height: 100%;
        }

        .footer-content-wrapper {
            position: relative;
            z-index: 2;
            padding: 60px 0 40px;
        }

        .footer-columns {
            display: flex;
            flex-wrap: wrap;
            gap: 50px;
            margin-bottom: 40px;
        }

        .footer-column {
            flex: 1;
            min-width: 200px;
        }

        .footer-column h3 {
            font-size: 1.3rem;
            margin-bottom: 20px;
            color: white;
        }

        .footer-column ul {
            list-style: none;
        }

        .footer-column ul li {
            margin-bottom: 10px;
        }

        .footer-column a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-column a:hover {
            color: white;
        }

        .notice {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.8);
        }

        .copyright {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.9rem;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .footer-columns {
                gap: 30px;
            }
        }

        @media (max-width: 768px) {
            .footer-columns {
                flex-direction: column;
                gap: 40px;
            }
            .footer-column {
                min-width: 100%;
            }
        }
    </style>

    <script>
        // Profile dropdown toggle
        const profileIcon = document.getElementById('profileIcon');
        const profileDropdown = document.getElementById('profileDropdown');

        if (profileIcon) {
            profileIcon.addEventListener('click', (e) => {
                e.stopPropagation();
                profileDropdown.classList.toggle('active');
            });
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', () => {
            if (profileDropdown) {
                profileDropdown.classList.remove('active');
            }
        });

        // Show Reviews button toggle
        const showReviewsBtn = document.getElementById('showReviewsBtn');
        const reviewsGrid = document.getElementById('reviewsGrid');

        if (showReviewsBtn && reviewsGrid) {
            showReviewsBtn.addEventListener('click', () => {
                if (reviewsGrid.style.display === 'none' || reviewsGrid.style.display === '') {
                    reviewsGrid.style.display = 'grid';
                    showReviewsBtn.textContent = 'Hide Reviews';
                } else {
                    reviewsGrid.style.display = 'none';
                    showReviewsBtn.textContent = 'Show Reviews';
                }
            });
        }
    </script>

</body>
</html>
