<?php
require_once 'config.php';

try {
    // Add user_id to reviews table if it doesn't exist
    $checkColumn = $conn->query("SHOW COLUMNS FROM reviews LIKE 'user_id'");
    if ($checkColumn->rowCount() == 0) {
        $conn->exec("ALTER TABLE reviews ADD COLUMN user_id INT DEFAULT NULL");
        echo "Added user_id column to reviews table<br>";
    } else {
        echo "user_id column already exists in reviews table<br>";
    }

    // Create businesses table if it doesn't exist
    $sql = "CREATE TABLE IF NOT EXISTS businesses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        business_name VARCHAR(255) NOT NULL,
        industry VARCHAR(100) NOT NULL,
        description TEXT NOT NULL,
        country VARCHAR(100) NOT NULL,
        logo_url VARCHAR(255),
        website VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB";
    $conn->exec($sql);
    echo "Businesses table created successfully or already exists<br>";

    // Create jobs table if it doesn't exist
    $sql = "CREATE TABLE IF NOT EXISTS jobs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        job_title VARCHAR(255) NOT NULL,
        company_name VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        salary_min DECIMAL(10, 2),
        salary_max DECIMAL(10, 2),
        job_type VARCHAR(50) NOT NULL,
        location VARCHAR(100) NOT NULL,
        skills_required TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB";
    $conn->exec($sql);
    echo "Jobs table created successfully or already exists<br>";

    echo "Database migration completed!";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
